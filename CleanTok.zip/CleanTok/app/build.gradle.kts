plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.cleantok.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.cleantok.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "3.0"
    }

    flavorDimensions += "engine"
    productFlavors {
        // Лёгкая версия на системном WebView (Chrome/Android System WebView)
        create("webview") {
            dimension = "engine"
            applicationIdSuffix = ".wv"
            versionNameSuffix = "-webview"
            resValue("string", "app_name", "CleanTok")
        }
        // Версия с движком Firefox внутри APK — для Huawei и любых телефонов без сервисов Google
        create("gecko") {
            dimension = "engine"
            applicationIdSuffix = ".gecko"
            versionNameSuffix = "-gecko"
            resValue("string", "app_name", "CleanTok G")
            ndk {
                abiFilters += listOf("arm64-v8a", "armeabi-v7a")
            }
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            // Подписываем debug-ключом, чтобы APK можно было установить без своего keystore
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")

    "webviewImplementation"("androidx.webkit:webkit:1.12.1")
    "geckoImplementation"("org.mozilla.geckoview:geckoview:130.0.20240829075237")
}
