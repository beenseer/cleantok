plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.cleantok.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.cleantok.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"

        // GeckoView содержит нативные библиотеки; оставляем только ARM, чтобы APK был меньше
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            // Подписываем debug-ключом, чтобы APK можно было установить без своего keystore
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    // Движок Firefox: работает независимо от системного WebView (важно для Huawei без сервисов Google)
    implementation("org.mozilla.geckoview:geckoview:130.0.20240829075237")
}
