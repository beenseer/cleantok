package com.cleantok.app

import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.GeckoView

object EngineFactory {
    fun create(
        activity: AppCompatActivity,
        container: FrameLayout,
        fullscreenContainer: FrameLayout,
        host: EngineHost,
        desktop: Boolean
    ): Engine = GeckoEngine(activity, container, host, desktop)
}

class GeckoEngine(
    private val activity: AppCompatActivity,
    container: FrameLayout,
    private val host: EngineHost,
    private var desktop: Boolean
) : Engine {

    private val geckoView = GeckoView(activity)
    private lateinit var session: GeckoSession

    private var canBack = false
    private var lastUrl: String? = null

    private var extensionReady = false
    private var pendingUrl: String? = null
    private val handler = Handler(Looper.getMainLooper())

    init {
        container.addView(
            geckoView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        val rt = runtime ?: GeckoRuntime.create(activity.applicationContext).also { runtime = it }
        session = createSession(rt)

        // Встроенное расширение: баннеры, плеер, жесты. Страницы грузим после его установки.
        rt.webExtensionController
            .ensureBuiltIn(EXTENSION_LOCATION, EXTENSION_ID)
            .accept(
                { _ -> onExtensionReady() },
                { _ ->
                    Toast.makeText(activity, R.string.extension_failed, Toast.LENGTH_LONG).show()
                    onExtensionReady()
                }
            )

        // Если установка расширения затянулась или не завершилась — не ждём вечно, грузим страницу без него
        handler.postDelayed({
            if (!extensionReady) {
                Toast.makeText(activity, R.string.extension_failed, Toast.LENGTH_LONG).show()
                onExtensionReady()
            }
        }, EXTENSION_TIMEOUT_MS)
    }

    private fun createSession(rt: GeckoRuntime): GeckoSession {
        // Для режима ПК меняем только User-Agent; viewport оставляем «мобильным», чтобы работал наш meta viewport
        val settings = GeckoSessionSettings.Builder()
            .usePrivateMode(false)
            .userAgentMode(
                if (desktop) GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
                else GeckoSessionSettings.USER_AGENT_MODE_MOBILE
            )
            .viewportMode(GeckoSessionSettings.VIEWPORT_MODE_MOBILE)
            .build()

        val s = GeckoSession(settings)

        s.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLoadRequest(
                session: GeckoSession,
                request: GeckoSession.NavigationDelegate.LoadRequest
            ): GeckoResult<AllowOrDeny>? {
                val allowed = host.isLoadAllowed(request.uri, request.isRedirect)
                if (allowed && request.uri != "about:blank") lastUrl = request.uri
                return GeckoResult.fromValue(if (allowed) AllowOrDeny.ALLOW else AllowOrDeny.DENY)
            }

            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                canBack = canGoBack
            }

            // Всплывающие окна запрещены
            override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? = null
        }

        s.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                host.onProgress(true)
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                host.onProgress(false)
            }

            override fun onProgressChange(session: GeckoSession, progress: Int) {
                host.onProgress(progress < 100)
            }
        }

        s.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
                host.onFullscreen(fullScreen)
            }

            override fun onCrash(session: GeckoSession) {
                host.onFatal()
            }
        }

        s.open(rt)
        geckoView.setSession(s)
        return s
    }

    private fun onExtensionReady() {
        if (extensionReady && pendingUrl == null) return
        extensionReady = true
        pendingUrl?.let { session.loadUri(it) }
        pendingUrl = null
    }

    override fun load(url: String) {
        lastUrl = url
        if (extensionReady) session.loadUri(url) else pendingUrl = url
    }

    override fun reload() {
        session.reload()
    }

    override fun canGoBack(): Boolean = canBack

    override fun goBack() {
        session.goBack()
    }

    override fun currentUrl(): String? = lastUrl

    override fun reset() {
        val rt = runtime ?: return
        val old = session
        canBack = false
        lastUrl = null
        pendingUrl = null
        session = createSession(rt)
        old.close()
    }

    override fun setDesktopMode(desktop: Boolean) {
        if (this.desktop == desktop) return
        this.desktop = desktop
        val rt = runtime ?: return
        val url = lastUrl
        val old = session
        canBack = false
        session = createSession(rt)
        old.close()
        if (url != null && url != "about:blank") load(url)
    }

    override fun isDesktopMode(): Boolean = desktop

    override fun exitFullscreen() {
        session.exitFullScreen()
    }

    override fun onResume() {
        // Сессию не деактивируем при сворачивании, чтобы звук не прерывался
        session.setActive(true)
    }

    override fun destroy() {
        handler.removeCallbacksAndMessages(null)
        session.close()
    }

    companion object {
        private var runtime: GeckoRuntime? = null

        private const val EXTENSION_LOCATION = "resource://android/assets/cleantok/"
        private const val EXTENSION_ID = "cleantok@cleantok.app"
        private const val EXTENSION_TIMEOUT_MS = 4000L
    }
}
