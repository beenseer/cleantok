package com.cleantok.app

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

object EngineFactory {
    fun create(
        activity: AppCompatActivity,
        container: FrameLayout,
        fullscreenContainer: FrameLayout,
        host: EngineHost
    ): Engine = WebViewEngine(activity, container, fullscreenContainer, host)
}

@SuppressLint("SetJavaScriptEnabled")
class WebViewEngine(
    private val activity: AppCompatActivity,
    container: FrameLayout,
    private val fullscreenContainer: FrameLayout,
    private val host: EngineHost
) : Engine {

    private val webView = WebView(activity)
    private val script: String =
        activity.assets.open("cleantok/content.js").bufferedReader().use { it.readText() }

    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var clearHistoryPending = false

    init {
        container.addView(
            webView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        webView.setBackgroundColor(Color.BLACK)

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            userAgentString = Const.MOBILE_UA
            useWideViewPort = true
            loadWithOverviewMode = false
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }

        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(webView.settings, true)
        }

        // Скрипт запускается до скриптов страницы, если WebView это умеет; иначе — после начала загрузки
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(
                webView,
                script,
                setOf("https://*.tiktok.com", "https://tiktok.com")
            )
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme?.lowercase()
                // intent://, snssdk1233://, market:// и прочие внешние схемы — блокируем
                if (scheme != "http" && scheme != "https") return true
                if (!request.isForMainFrame) return false
                return !host.isLoadAllowed(uri.toString(), request.isRedirect)
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (url != null && url != "about:blank") view.evaluateJavascript(script, null)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                if (url == "about:blank") {
                    if (clearHistoryPending) {
                        view.clearHistory()
                        clearHistoryPending = false
                    }
                } else if (url != null) {
                    view.evaluateJavascript(script, null)
                }
                host.onProgress(false)
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                host.onFatal()
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                host.onProgress(newProgress < 100)
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customCallback = callback
                fullscreenContainer.addView(
                    view,
                    FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                )
                fullscreenContainer.visibility = View.VISIBLE
                host.onFullscreen(true)
            }

            override fun onHideCustomView() {
                hideCustomView()
            }

            override fun getDefaultVideoPoster(): Bitmap? =
                Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)

            // Всплывающие окна запрещены
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean = false
        }
    }

    private fun hideCustomView() {
        val view = customView ?: return
        fullscreenContainer.removeView(view)
        fullscreenContainer.visibility = View.GONE
        customCallback?.onCustomViewHidden()
        customView = null
        customCallback = null
        host.onFullscreen(false)
    }

    override fun load(url: String) {
        webView.loadUrl(url)
    }

    override fun reload() {
        webView.reload()
    }

    override fun canGoBack(): Boolean = webView.canGoBack()

    override fun goBack() {
        webView.goBack()
    }

    override fun currentUrl(): String? = webView.url

    override fun reset() {
        clearHistoryPending = true
        webView.loadUrl("about:blank")
    }

    override fun exitFullscreen() {
        hideCustomView()
    }

    override fun onResume() {
        webView.onResume()
    }

    override fun destroy() {
        (webView.parent as? ViewGroup)?.removeView(webView)
        webView.destroy()
    }
}
