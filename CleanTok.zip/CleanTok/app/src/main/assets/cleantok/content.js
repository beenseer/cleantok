(function () {
  'use strict';

  if (window.__cleanTokInstalled) {
    if (window.__cleanTokSweep) window.__cleanTokSweep();
    return;
  }
  window.__cleanTokInstalled = true;

  // ───────────────────────── Журнал событий (попадает в отчёт диагностики) ─────────────────────────
  var T0 = Date.now();
  var LOG = [];
  var POPUPS = [];
  function log(msg) {
    if (LOG.length > 150) LOG.shift();
    LOG.push(((Date.now() - T0) / 1000).toFixed(1) + 's ' + msg);
  }
  window.addEventListener('error', function (e) {
    log('ERR ' + (e && e.message) + ' @' + String((e && e.filename) || '').slice(-40) + ':' + (e && e.lineno));
  });

  // Режим определяем по User-Agent: версия для ПК не содержит Android/Mobile
  var DESKTOP = !/Mobi|Android/i.test(navigator.userAgent || '');
  var DESK_W = 1280;

  // В GeckoView скрипт расширения живёт в изолированном мире, страница доступна через wrappedJSObject
  var PAGE = window.wrappedJSObject || null;

  // ───────────────────────── Тёмная тема ─────────────────────────
  try {
    localStorage.setItem('tiktok_webapp_theme', 'dark');
    localStorage.setItem('tiktok_webapp_theme_source', 'dark');
  } catch (e) {}
  try { document.cookie = 'tiktok_webapp_theme=dark; path=/; max-age=31536000'; } catch (e) {}

  // ───────────────────────── Работа в фоне: страница не должна знать, что она скрыта ─────────────────────────
  function defGetter(prop, value) {
    try {
      if (PAGE && typeof exportFunction === 'function') {
        Object.defineProperty(PAGE.document, prop, {
          get: exportFunction(function () { return value; }, window),
          configurable: true
        });
      } else {
        Object.defineProperty(document, prop, { get: function () { return value; }, configurable: true });
      }
    } catch (e) {}
  }
  defGetter('hidden', false);
  defGetter('webkitHidden', false);
  defGetter('visibilityState', 'visible');
  defGetter('webkitVisibilityState', 'visible');
  ['visibilitychange', 'webkitvisibilitychange'].forEach(function (name) {
    window.addEventListener(name, function (e) { e.stopImmediatePropagation(); }, true);
    document.addEventListener(name, function (e) { e.stopImmediatePropagation(); }, true);
  });

  // ───────────────────────── Viewport для версии ПК ─────────────────────────
  var viewportWanted = null;

  function setViewport(content) {
    try {
      var m = document.querySelector('meta[name="viewport"]');
      if (!m) {
        m = document.createElement('meta');
        m.setAttribute('name', 'viewport');
        (document.head || document.documentElement).appendChild(m);
      }
      if (m.getAttribute('content') !== content) m.setAttribute('content', content);
      viewportWanted = content;
    } catch (e) {}
  }

  if (DESKTOP) {
    var sw0 = window.screen && window.screen.width ? window.screen.width : 360;
    setViewport('width=' + DESK_W + ', initial-scale=' + Math.min(1, sw0 / DESK_W).toFixed(3) +
      ', minimum-scale=0.15, maximum-scale=6, user-scalable=yes');
  }

  // ───────────────────────── CSS ─────────────────────────
  var CSS = [
    'html { color-scheme: dark !important; }',
    'html.ct-video, html.ct-video body { overflow: hidden !important; overscroll-behavior: none !important; background: #000 !important; }',
    'html.ct-video video { object-fit: contain !important; background: #000 !important; }',
    'html.ct-mobile body { background: #000 !important; }',
    'a[href="/foryou"], a[href^="/foryou?"], a[href="/explore"], a[href="/following"],',
    '[data-e2e="nav-foryou"], [data-e2e="nav-explore"], [data-e2e="nav-following"],',
    '[data-e2e="login-modal"] { display: none !important; }',
    // мобильная версия: баннеры «Открыть приложение», окно-приглашение, плашка «Смотреть в TikTok», рекомендации
    'html.ct-mobile [data-e2e="top-banner"], html.ct-mobile [data-e2e="bottom-banner"], html.ct-mobile [data-e2e="bottom_banner"],',
    'html.ct-mobile [class*="DivFixedWrapper"], html.ct-mobile [class*="DivCamera"], html.ct-mobile [class*="DivBottomButtonSection"],',
    'html.ct-mobile .tux-base-dialog, html.ct-mobile tiktok-cookie-banner, html.ct-mobile [data-e2e="recommend-list-tab-container"] { display: none !important; }',
    // версия для ПК: боковое меню, шапка, затемнение, стрелки ленты
    'html.ct-desktop [class*="DivSideNavContainer"], html.ct-desktop #app-header, html.ct-desktop [class*="DivFixedTopContainer"],',
    'html.ct-desktop [class*="DivModalMask"], html.ct-desktop [data-e2e="feed-navigation-prev"], html.ct-desktop [data-e2e="feed-navigation-next"] { display: none !important; }',
    '.ct-ui { font: 14px/1.2 sans-serif; box-sizing: border-box; }',
    '#ct-bar { position: fixed; left: 0; right: 0; bottom: 0; z-index: 2147483647; display: none; align-items: center; gap: 8px;',
    '  padding: 4px 10px calc(4px + env(safe-area-inset-bottom)); background: rgba(0,0,0,0.55); color: #fff;',
    '  transition: opacity 0.3s; }',
    '#ct-bar.ct-idle { opacity: 0; pointer-events: none; }',
    '#ct-pp { width: 36px; height: 36px; border: 0; border-radius: 18px; background: #25c7d9; color: #000; font-size: 15px; flex: none; padding: 0; }',
    '#ct-time { flex: none; min-width: 78px; text-align: center; font-size: 12px; }',
    '#ct-seek { flex: 1; min-width: 0; height: 28px; accent-color: #25c7d9; }',
    '#ct-badge { position: fixed; top: 18%; left: 50%; transform: translateX(-50%); z-index: 2147483647; display: none;',
    '  padding: 6px 14px; border-radius: 16px; background: rgba(0,0,0,0.65); color: #fff; font-weight: bold; font-size: 16px; }',
    '.ct-fab { position: fixed; z-index: 2147483647; width: 36px; height: 36px; border-radius: 18px; border: 0; padding: 0;',
    '  background: rgba(0,0,0,0.55); color: #fff; font-size: 16px; opacity: 0.8; }',
    '#ct-unmute { position: fixed; z-index: 2147483647; left: 50%; bottom: 70px; transform: translateX(-50%); display: none; border: 0;',
    '  border-radius: 20px; padding: 10px 18px; background: #25c7d9; color: #000; font-size: 15px; font-weight: bold; }',
    '#ct-diag { left: 8px; bottom: 64px; }',
    '#ct-fit { left: 52px; bottom: 64px; display: none; }',
    '#ct-report { position: fixed; z-index: 2147483647; left: 0; right: 0; top: 0; bottom: 0; display: none; flex-direction: column;',
    '  gap: 8px; padding: 12px; background: rgba(0,0,0,0.92); color: #fff; }',
    '#ct-report textarea { flex: 1; width: 100%; background: #111; color: #ddd; border: 1px solid #444; font: 11px/1.3 monospace; }',
    '#ct-report .ct-row { display: flex; gap: 8px; }',
    '#ct-report button { flex: 1; height: 40px; border: 0; border-radius: 8px; background: #25c7d9; color: #000; font-size: 15px; }'
  ].join('\n');

  function ensureStyle() {
    var root = document.head || document.documentElement;
    if (!root || document.getElementById('__cleantok_style')) return;
    var el = document.createElement('style');
    el.id = '__cleantok_style';
    el.textContent = CSS;
    root.appendChild(el);
  }

  // ───────────────────────── Вспомогательное ─────────────────────────
  function isVideoPage() { return /\/(video|photo)\//.test(location.pathname); }

  function isOurs(n) {
    var el = n && n.nodeType === 1 ? n : (n && n.parentElement);
    return !!(el && el.closest && el.closest('.ct-ui'));
  }

  function visibleArea(r) {
    var w = Math.min(r.right, window.innerWidth) - Math.max(r.left, 0);
    var h = Math.min(r.bottom, window.innerHeight) - Math.max(r.top, 0);
    return w > 0 && h > 0 ? w * h : 0;
  }

  // Основное видео: то, что больше всего видно на экране (страница подгружает и соседние ролики)
  var cachedVideo = null;
  function mainVideo() {
    var vs = document.getElementsByTagName('video');
    var best = null, bestScore = 0;
    for (var i = 0; i < vs.length; i++) {
      var v = vs[i];
      var a = visibleArea(v.getBoundingClientRect());
      if (!a) continue;
      var score = a * (v.paused ? 1 : 1.5) * (v.readyState > 0 ? 1.2 : 1);
      if (v === cachedVideo) score *= 1.3;
      if (score > bestScore) { bestScore = score; best = v; }
    }
    cachedVideo = best;
    return best;
  }

  function hideEl(el, kind) {
    el.style.setProperty('display', 'none', 'important');
    el.setAttribute('data-ct-hidden', kind || '1');
  }

  function setImp(el, prop, val) {
    if (el.style.getPropertyValue(prop) === val && el.style.getPropertyPriority(prop) === 'important') return;
    el.style.setProperty(prop, val, 'important');
  }

  function fmt(s) {
    if (!isFinite(s) || s < 0) s = 0;
    var m = Math.floor(s / 60), sec = Math.floor(s % 60);
    return m + ':' + (sec < 10 ? '0' : '') + sec;
  }

  function desc(el) {
    if (!el || !el.tagName) return String(el);
    var c = typeof el.className === 'string' ? el.className.trim().split(/\s+/).slice(0, 3).join('.') : '';
    var r = el.getBoundingClientRect();
    return el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') + (c ? '.' + c : '') +
      ' [' + Math.round(r.width) + 'x' + Math.round(r.height) + '@' + Math.round(r.left) + ',' + Math.round(r.top) + ']';
  }

  function styleInfo(el) {
    var s = window.getComputedStyle(el);
    return 'pos=' + s.position + ' disp=' + s.display + ' ovf=' + s.overflowY + ' tr=' + (s.transform === 'none' ? '-' : 'y') + ' h=' + s.height;
  }

  // ───────────────────────── Раскладка плеера (мобильный режим): на весь экран, без полос ─────────────────────────
  var fitted = [];

  function unlayout() {
    fitted.forEach(function (rec) {
      try {
        if (rec.old === null) rec.el.removeAttribute('style'); else rec.el.setAttribute('style', rec.old);
        rec.el.removeAttribute('data-ct-fit');
      } catch (e) {}
    });
    fitted = [];
  }

  function layoutPlayer(v) {
    var vh = window.innerHeight, vw = window.innerWidth;
    if (!vh || !vw) return;
    var n = v, chain = [];
    for (var i = 0; i < 12 && n && n !== document.body && n !== document.documentElement; i++) {
      chain.push(n);
      n = n.parentElement;
    }
    for (var j = 0; j < chain.length; j++) {
      var el = chain[j];
      var r = el.getBoundingClientRect();
      if (r.width < vw * 0.8) continue;
      if (!el.getAttribute('data-ct-fit')) {
        fitted.push({ el: el, old: el.getAttribute('style') });
        el.setAttribute('data-ct-fit', '1');
      }
      var px = vh + 'px';
      setImp(el, 'height', px);
      setImp(el, 'min-height', px);
      setImp(el, 'max-height', 'none');
      setImp(el, 'aspect-ratio', 'auto');
      setImp(el, 'padding-top', '0');
      setImp(el, 'padding-bottom', '0');
      setImp(el, 'margin-top', '0');
      el.scrollTop = 0;
    }
    setImp(v, 'width', '100%');
    setImp(v, 'height', vh + 'px');
    if (window.scrollY || window.scrollX) window.scrollTo(0, 0);
  }

  // ───────────────────────── Версия для ПК: масштаб под окно видео ─────────────────────────
  var fit = { key: '', w: 0, h: 0, count: 0, userZoomed: false };

  function fitDesktop(force) {
    if (!DESKTOP || !isVideoPage()) return;
    var key = location.pathname;
    if (fit.key !== key) fit = { key: key, w: 0, h: 0, count: 0, userZoomed: false };
    if (!force && fit.userZoomed) return;
    var v = mainVideo();
    if (!v) return;
    var r = v.getBoundingClientRect();
    if (r.width < 120 || r.height < 120) return;
    if (!force) {
      // Раскладка страницы меняется несколько секунд после загрузки: подгоняем заново, пока размер видео не устоится
      if (fit.count >= 6) return;
      var same = fit.w && Math.abs(r.width - fit.w) < fit.w * 0.06 && Math.abs(r.height - fit.h) < fit.h * 0.06;
      if (same) return;
    }
    fit.w = r.width;
    fit.h = r.height;
    fit.count++;
    var sw = (window.screen && window.screen.width) || 360;
    var sh = (window.screen && window.screen.height) || 640;
    var s = Math.min(sw / (r.width + 24), (sh * 0.85) / (r.height + 24));
    s = Math.max(0.2, Math.min(4, s));
    var x = r.left + (window.pageXOffset || 0) - 12;
    var y = r.top + (window.pageYOffset || 0) - 12;
    var content = 'width=' + DESK_W + ', initial-scale=' + s.toFixed(3) + ', minimum-scale=0.15, maximum-scale=6, user-scalable=yes';
    try {
      // пересоздаём meta, чтобы движок заново применил масштаб
      var old = document.querySelector('meta[name="viewport"]');
      if (old && old.parentNode) old.parentNode.removeChild(old);
    } catch (e) {}
    setViewport(content);
    log('fit#' + fit.count + ' want=' + s.toFixed(3) + ' video=' + Math.round(r.width) + 'x' + Math.round(r.height) + ' at ' + Math.round(x) + ',' + Math.round(y));
    setTimeout(function () {
      window.scrollTo(Math.max(0, x), Math.max(0, y));
      var vv = window.visualViewport;
      log('fit result vv.scale=' + (vv ? vv.scale.toFixed(3) : '-') + ' scroll=' + Math.round(window.pageXOffset) + ',' + Math.round(window.pageYOffset));
    }, 400);
  }

  // В ленте версии для ПК остальные ролики не нужны: прячем их, чтобы не листалось и не играло параллельно
  function hideOtherFeedItems(v) {
    var items = document.querySelectorAll('article[id^="one-column-item-"]');
    for (var i = 0; i < items.length; i++) {
      if (!items[i].contains(v) && !items[i].getAttribute('data-ct-hidden')) hideEl(items[i], 'feed');
    }
  }

  // ───────────────────────── Скорость 2× (мобильный режим) ─────────────────────────
  var pressTimer = null, speedActive = false, speedLocked = false, speedTouched = false;
  var startX = 0, startY = 0, toggledThisPress = false, swallowClickUntil = 0, lastTouchAt = Date.now();
  var badge = null;

  function showBadge() {
    if (!badge) {
      badge = document.createElement('div');
      badge.id = 'ct-badge';
      badge.className = 'ct-ui';
      document.documentElement.appendChild(badge);
    }
    if (speedActive || speedLocked) {
      badge.textContent = speedLocked ? '2× (закреплено)' : '2×';
      badge.style.display = 'block';
    } else {
      badge.style.display = 'none';
    }
  }

  function applySpeed() {
    var v = mainVideo();
    if (!v) return;
    var want = (speedActive || speedLocked) ? 2 : 1;
    if (want === 2) {
      speedTouched = true;
      if (v.playbackRate !== 2) v.playbackRate = 2;
    } else if (speedTouched) {
      if (v.playbackRate !== 1) v.playbackRate = 1;
      speedTouched = false;
    }
  }

  function buzz() { try { if (navigator.vibrate) navigator.vibrate(15); } catch (e) {} }
  function cancelPress() { if (pressTimer) { clearTimeout(pressTimer); pressTimer = null; } }

  function inScrollable(el) {
    var n = el, depth = 0;
    while (n && n !== document.body && n !== document.documentElement && depth < 20) {
      var cs = window.getComputedStyle(n);
      if ((cs.overflowY === 'auto' || cs.overflowY === 'scroll') && n.scrollHeight > n.clientHeight + 2) return true;
      n = n.parentElement;
      depth++;
    }
    return false;
  }

  function pointInVideo(t, v) {
    var r = v.getBoundingClientRect();
    return t.clientX >= r.left && t.clientX <= r.right && t.clientY >= r.top && t.clientY <= r.bottom;
  }

  window.addEventListener('touchstart', function (e) {
    lastTouchAt = Date.now();
    if (DESKTOP && e.touches && e.touches.length > 1) fit.userZoomed = true;
    cancelPress();
    if (DESKTOP || !isVideoPage() || e.touches.length !== 1 || isOurs(e.target)) return;
    var v = mainVideo();
    if (!v) return;
    var t = e.touches[0];
    if (!pointInVideo(t, v)) return;
    var r = v.getBoundingClientRect();
    var edge = r.width * 0.2;
    if (t.clientX > r.left + edge && t.clientX < r.right - edge) return;
    startX = t.clientX;
    startY = t.clientY;
    toggledThisPress = false;
    pressTimer = setTimeout(function () {
      pressTimer = null;
      speedActive = true;
      applySpeed();
      showBadge();
      buzz();
    }, 450);
  }, { passive: true, capture: true });

  window.addEventListener('touchmove', function (e) {
    if (DESKTOP) return;
    var t = e.touches && e.touches[0];

    if (speedActive) {
      if (e.cancelable) e.preventDefault();
      e.stopImmediatePropagation();
      if (t && !toggledThisPress && t.clientY - startY > 70) {
        toggledThisPress = true;
        speedLocked = !speedLocked;
        showBadge();
        applySpeed();
        buzz();
      }
      return;
    }

    if (pressTimer && t && (Math.abs(t.clientX - startX) > 12 || Math.abs(t.clientY - startY) > 12)) cancelPress();

    // Не даём перелистнуть ролик свайпом по видео; листаемые области (профиль, комментарии) не трогаем
    if (!isVideoPage() || !t || isOurs(e.target) || inScrollable(e.target)) return;
    var v = mainVideo();
    if (v && pointInVideo(t, v)) {
      if (e.cancelable) e.preventDefault();
      e.stopImmediatePropagation();
    }
  }, { passive: false, capture: true });

  function endPress() {
    cancelPress();
    if (speedActive) {
      speedActive = false;
      swallowClickUntil = Date.now() + 400;
      applySpeed();
      showBadge();
    }
  }
  window.addEventListener('touchend', endPress, { passive: true, capture: true });
  window.addEventListener('touchcancel', endPress, { passive: true, capture: true });

  window.addEventListener('contextmenu', function (e) {
    if (pressTimer || speedActive) e.preventDefault();
  }, true);

  window.addEventListener('click', function (e) {
    if (Date.now() < swallowClickUntil) { e.preventDefault(); e.stopImmediatePropagation(); return; }
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a || isOurs(a)) return;
    var href = a.getAttribute('href') || '';
    var blocked = /^(\/|\/foryou|\/explore|\/following|\/login|\/signup|\/download)(\?|#|$)/.test(href);
    var external = /^(https?:)?\/\//i.test(href) && !/^(https?:)?\/\/([a-z0-9-]+\.)*tiktok\.com(\/|$)/i.test(href);
    if (blocked || external || /^(intent|market|snssdk\d*):/i.test(href)) {
      e.preventDefault();
      e.stopImmediatePropagation();
    }
  }, true);

  setInterval(function () { if (speedActive || speedLocked || speedTouched) applySpeed(); }, 500);

  // Пауза от касания пользователя запоминается, чтобы автозапуск её не отменял
  document.addEventListener('pause', function (e) {
    var t = e.target;
    if (t && t.tagName === 'VIDEO' && Date.now() - lastTouchAt < 700) t.__ctUserPaused = true;
  }, true);
  document.addEventListener('play', function (e) {
    var t = e.target;
    if (t && t.tagName === 'VIDEO') t.__ctUserPaused = false;
  }, true);

  // Остальные видео на странице (подгруженные соседние, превью рекомендаций) должны молчать
  function quietOthers(main) {
    var vs = document.getElementsByTagName('video');
    for (var i = 0; i < vs.length; i++) {
      var o = vs[i];
      if (o === main) continue;
      if (!o.paused) {
        try { o.pause(); } catch (e) {}
        if (!o.__ctQuiet) log('paused other video ' + desc(o));
      }
      if (!o.muted) o.muted = true;
      o.__ctQuiet = true;
    }
  }

  // Автозапуск: сначала со звуком; если движок запретил — без звука и кнопка «Включить звук»
  function ensurePlaying(v) {
    if (!v.paused || v.ended || v.__ctUserPaused || v.readyState < 2) return;
    var now = Date.now();
    if (v.__ctTryAt && now - v.__ctTryAt < 2500) return;
    v.__ctTryAt = now;
    v.__ctTries = (v.__ctTries || 0) + 1;
    if (v.__ctTries > 8) return;
    var p;
    try { p = v.play(); } catch (e) { return; }
    if (p && p.catch) {
      p.catch(function () {
        if (v.muted) return;
        v.muted = true;
        v.__ctMutedByUs = true;
        log('autoplay blocked: playing muted');
        var q;
        try { q = v.play(); } catch (e) {}
        if (q && q.catch) q.catch(function () {});
      });
    }
  }

  function unmute() {
    var vs = document.getElementsByTagName('video');
    for (var i = 0; i < vs.length; i++) {
      if (vs[i].__ctMutedByUs) {
        vs[i].muted = false;
        vs[i].volume = 1;
        vs[i].__ctMutedByUs = false;
        if (vs[i].paused) { try { var p = vs[i].play(); if (p && p.catch) p.catch(function () {}); } catch (e) {} }
      }
    }
  }

  // ───────────────────────── Наш интерфейс: панель, диагностика ─────────────────────────
  var bar = null, pp = null, timeEl = null, seek = null, dragging = false;
  var diagBtn = null, fitBtn = null, report = null, reportText = null, unmuteBtn = null;

  function buildUi() {
    if (bar && bar.isConnected) return;
    var root = document.documentElement;

    bar = document.createElement('div');
    bar.id = 'ct-bar';
    bar.className = 'ct-ui';
    pp = document.createElement('button');
    pp.id = 'ct-pp';
    pp.type = 'button';
    timeEl = document.createElement('span');
    timeEl.id = 'ct-time';
    seek = document.createElement('input');
    seek.id = 'ct-seek';
    seek.type = 'range';
    seek.min = '0';
    seek.max = '1000';
    seek.step = '1';
    seek.value = '0';
    bar.appendChild(pp);
    bar.appendChild(timeEl);
    bar.appendChild(seek);
    root.appendChild(bar);

    ['touchstart', 'touchend', 'click', 'pointerdown', 'mousedown'].forEach(function (n) {
      bar.addEventListener(n, function (e) { e.stopPropagation(); });
    });

    pp.addEventListener('click', function () {
      var v = mainVideo();
      if (!v) return;
      if (v.__ctMutedByUs) unmute();
      if (v.ended || v.paused) {
        v.__ctUserPaused = false;
        if (v.ended) v.currentTime = 0;
        var p = v.play();
        if (p && p.catch) p.catch(function () {});
      } else {
        v.__ctUserPaused = true;
        v.pause();
      }
      updateBar();
    });
    seek.addEventListener('touchstart', function () { dragging = true; });
    seek.addEventListener('pointerdown', function () { dragging = true; });
    // Пока палец двигается — только показываем время, перемотку делаем при отпускании
    seek.addEventListener('input', function () {
      var v = mainVideo();
      if (v && isFinite(v.duration)) timeEl.textContent = fmt((seek.value / 1000) * v.duration) + ' / ' + fmt(v.duration);
    });
    seek.addEventListener('change', function () {
      var v = mainVideo();
      if (v && isFinite(v.duration)) v.currentTime = (seek.value / 1000) * v.duration;
      dragging = false;
    });
    seek.addEventListener('touchend', function () { setTimeout(function () { dragging = false; }, 150); });

    unmuteBtn = document.createElement('button');
    unmuteBtn.id = 'ct-unmute';
    unmuteBtn.className = 'ct-ui';
    unmuteBtn.type = 'button';
    unmuteBtn.textContent = '🔇 Включить звук';
    unmuteBtn.addEventListener('click', function (e) { e.stopPropagation(); unmute(); updateBar(); });
    root.appendChild(unmuteBtn);

    diagBtn = document.createElement('button');
    diagBtn.id = 'ct-diag';
    diagBtn.className = 'ct-ui ct-fab';
    diagBtn.type = 'button';
    diagBtn.textContent = '🐞';
    diagBtn.addEventListener('click', function (e) { e.stopPropagation(); showReport(); });
    root.appendChild(diagBtn);

    fitBtn = document.createElement('button');
    fitBtn.id = 'ct-fit';
    fitBtn.className = 'ct-ui ct-fab';
    fitBtn.type = 'button';
    fitBtn.textContent = '⤢';
    fitBtn.addEventListener('click', function (e) { e.stopPropagation(); fitDesktop(true); });
    root.appendChild(fitBtn);

    report = document.createElement('div');
    report.id = 'ct-report';
    report.className = 'ct-ui';
    reportText = document.createElement('textarea');
    var row = document.createElement('div');
    row.className = 'ct-row';
    var bCopy = document.createElement('button');
    bCopy.type = 'button';
    bCopy.textContent = 'Копировать';
    var bClose = document.createElement('button');
    bClose.type = 'button';
    bClose.textContent = 'Закрыть';
    row.appendChild(bCopy);
    row.appendChild(bClose);
    report.appendChild(reportText);
    report.appendChild(row);
    root.appendChild(report);
    bCopy.addEventListener('click', function () { copyReport(); });
    bClose.addEventListener('click', function () { report.style.display = 'none'; });
    ['touchstart', 'touchmove', 'touchend', 'click'].forEach(function (n) {
      report.addEventListener(n, function (e) { e.stopPropagation(); });
    });
  }

  function updateBar() {
    buildUi();
    fitBtn.style.display = DESKTOP ? 'block' : 'none';
    var main = isVideoPage() ? mainVideo() : null;
    if (main) {
      quietOthers(main);
      ensurePlaying(main);
    }
    unmuteBtn.style.display = (main && main.__ctMutedByUs) ? 'block' : 'none';
    var v = !DESKTOP ? main : null;
    if (!v) { bar.style.display = 'none'; return; }
    bar.style.display = 'flex';
    var idle = !v.paused && (Date.now() - lastTouchAt > 3500) && !dragging;
    bar.classList.toggle('ct-idle', idle);
    var label = v.paused ? '▶' : '❚❚';
    if (pp.textContent !== label) pp.textContent = label;
    if (!dragging) {
      var d = v.duration;
      if (isFinite(d) && d > 0) {
        var val = String(Math.round((v.currentTime / d) * 1000));
        if (seek.value !== val) seek.value = val;
      }
      var tt = fmt(v.currentTime) + ' / ' + fmt(d);
      if (timeEl.textContent !== tt) timeEl.textContent = tt;
    }
  }
  setInterval(function () { try { updateBar(); } catch (e) {} }, 300);

  // ───────────────────────── Диагностика ─────────────────────────
  function buildReport() {
    var out = [];
    function add(s) { out.push(s); }
    var meta = document.querySelector('meta[name="viewport"]');
    var vv = window.visualViewport;

    add('CleanTok report v3 ' + new Date().toISOString());
    add('mode=' + (DESKTOP ? 'DESKTOP' : 'MOBILE') + ' url=' + location.href);
    add('UA=' + navigator.userAgent);
    add('inner=' + window.innerWidth + 'x' + window.innerHeight + ' screen=' + (screen && screen.width) + 'x' + (screen && screen.height) +
      ' dpr=' + window.devicePixelRatio + ' vv=' + (vv ? vv.scale.toFixed(2) + ' ' + Math.round(vv.width) + 'x' + Math.round(vv.height) : '-') +
      ' scroll=' + Math.round(window.scrollX) + ',' + Math.round(window.scrollY));
    add('fit=' + JSON.stringify(fit));
    add('html.class=' + document.documentElement.className + ' viewportMeta=' + (meta ? meta.getAttribute('content') : '-'));
    add('theme ls=' + (function () { try { return localStorage.getItem('tiktok_webapp_theme'); } catch (e) { return '?'; } })() +
      ' bodyBg=' + (document.body ? window.getComputedStyle(document.body).backgroundColor : '-'));

    add('\n== VIDEO ==');
    var vs = document.getElementsByTagName('video');
    add('count=' + vs.length + ' main=' + (cachedVideo ? 'yes' : 'no'));
    for (var i = 0; i < vs.length && i < 6; i++) {
      var v = vs[i];
      add('#' + i + (v === cachedVideo ? '*' : '') + ' ' + desc(v) + ' paused=' + v.paused + ' ended=' + v.ended + ' ready=' + v.readyState +
        ' t=' + fmt(v.currentTime) + '/' + (isFinite(v.duration) ? fmt(v.duration) : v.duration) + ' rate=' + v.playbackRate + ' muted=' + v.muted + (v.__ctMutedByUs ? '(by us)' : '') + ' userPaused=' + !!v.__ctUserPaused +
        ' vw=' + v.videoWidth + 'x' + v.videoHeight + ' fit=' + window.getComputedStyle(v).objectFit);
      if (v === cachedVideo || (!cachedVideo && i === 0)) {
        var n = v.parentElement, k = 0;
        while (n && n !== document.documentElement && k < 9) {
          add('   ^ ' + desc(n) + ' ' + styleInfo(n) + (n.getAttribute('data-ct-fit') ? ' [fit]' : ''));
          n = n.parentElement;
          k++;
        }
      }
    }

    add('\n== BODY CHILDREN ==');
    if (document.body) {
      var ch = document.body.children;
      for (var b = 0; b < ch.length && b < 25; b++) add(desc(ch[b]) + ' ' + styleInfo(ch[b]) + (ch[b].getAttribute('data-ct-hidden') ? ' [hidden:' + ch[b].getAttribute('data-ct-hidden') + ']' : ''));
    }

    add('\n== FIXED / OVERLAY ELEMENTS ==');
    var all = document.querySelectorAll('div, section, aside, header, footer, nav, dialog');
    var fx = 0;
    for (var f = 0; f < all.length && fx < 40; f++) {
      var el = all[f];
      if (isOurs(el)) continue;
      var cs = window.getComputedStyle(el);
      if (cs.position !== 'fixed' && el.getAttribute('role') !== 'dialog') continue;
      var tx = (el.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 70);
      add(desc(el) + ' ' + cs.display + (el.getAttribute('data-ct-hidden') ? ' [hidden]' : '') + ' "' + tx + '"');
      fx++;
    }

    add('\n== DATA-E2E ==');
    var seen = {}, names = [];
    var e2 = document.querySelectorAll('[data-e2e]');
    for (var d = 0; d < e2.length && names.length < 120; d++) {
      var nm = e2[d].getAttribute('data-e2e');
      if (!seen[nm]) { seen[nm] = 1; names.push(nm); }
    }
    add(names.join(', '));

    add('\n== COMMENT / AUTHOR / ACTIONS ==');
    var cands = document.querySelectorAll('[data-e2e*="comment"], [data-e2e*="avatar"], [data-e2e*="user"], [data-e2e*="browse"], [data-e2e*="like"], [data-e2e*="share"]');
    for (var c = 0; c < cands.length && c < 14; c++) {
      add(desc(cands[c]) + ' e2e=' + cands[c].getAttribute('data-e2e') + ' html=' + cands[c].outerHTML.replace(/\s+/g, ' ').slice(0, 220));
    }
    var links = document.querySelectorAll('a[href*="/@"]');
    var hs = [];
    for (var l = 0; l < links.length && hs.length < 6; l++) hs.push(links[l].getAttribute('href'));
    add('links /@: ' + hs.join(' | '));

    add('\n== POPUPS (последние) ==');
    POPUPS.forEach(function (p) { add(p); });

    add('\n== LOG ==');
    LOG.forEach(function (s) { add(s); });

    var text = out.join('\n');
    return text.length > 16000 ? text.slice(0, 16000) + '\n...[обрезано]' : text;
  }

  function copyText(text, cb) {
    function fallback() {
      try {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.className = 'ct-ui';
        ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;z-index:-1';
        document.documentElement.appendChild(ta);
        ta.focus();
        ta.select();
        var ok = document.execCommand('copy');
        ta.remove();
        cb(!!ok);
      } catch (e) { cb(false); }
    }
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function () { cb(true); }, fallback);
        return;
      }
    } catch (e) {}
    fallback();
  }

  function copyReport() {
    copyText(reportText.value, function (ok) {
      var first = reportText.value.split('\n')[0];
      if (!ok) { reportText.focus(); reportText.select(); }
      log('copy ' + (ok ? 'ok' : 'failed') + ' ' + first.slice(0, 20));
      var b = report.querySelectorAll('button')[0];
      if (b) b.textContent = ok ? 'Скопировано ✓' : 'Не вышло: выделено, копируйте вручную';
    });
  }

  function showReport() {
    buildUi();
    reportText.value = buildReport();
    report.style.display = 'flex';
    report.querySelectorAll('button')[0].textContent = 'Копировать';
    copyReport();
  }
  window.__ctReport = showReport;

  // ───────────────────────── Зачистка баннеров, окон и рекомендаций ─────────────────────────
  var BANNER_RE = /^(открыть\s+(в\s+)?прил|открыть\s+tiktok|смотреть\s+в\s+tiktok|скачать|использовать приложение|продолжить в приложении|open\s+(in\s+)?app|open tiktok|watch\s+(this\s+)?(video\s+)?(in|on)\s+tiktok|get app|download|continue in app)/i;
  var REC_RE = /^(вам может понравиться|вам могут понравиться|you may like|more to explore|recommended|похожие видео|related videos)/i;
  var ENDCARD_RE = /(прокрутите вверх, чтобы увидеть больше|scroll up to see more|swipe up for more)/i;
  var POPUP_RE = /(воспользуйтесь всеми функциями|use all (the )?(app )?features|в приложении вас ждет|get the full (tiktok )?experience|продолжить в приложении|войдите в tiktok|войти в tiktok|log in to tiktok|sign up for tiktok)/i;
  var COOKIE_RE = /(cookie|куки)/i;
  var CAPTCHA_RE = /(captcha|verify|капч|проверк[аи])/i;

  function looksLikeCaptcha(el) {
    var meta = (el.id || '') + ' ' + (typeof el.className === 'string' ? el.className : '');
    if (CAPTCHA_RE.test(meta)) return true;
    return !!(el.querySelector && el.querySelector('iframe, [class*="aptcha"], [id*="aptcha"]'));
  }

  function bannerContainer(leaf) {
    var best = leaf, cur = leaf;
    for (var i = 0; i < 6; i++) {
      var p = cur.parentElement;
      if (!p || p === document.body || p === document.documentElement) break;
      if (p.querySelector('video')) break;
      if (p.offsetHeight > window.innerHeight * 0.25) break;
      best = p;
      cur = p;
    }
    return best;
  }

  function fixedAncestor(el) {
    var cur = el;
    for (var i = 0; i < 12 && cur && cur !== document.body && cur !== document.documentElement; i++) {
      var cs = window.getComputedStyle(cur);
      if (cs.position === 'fixed' || cs.position === 'sticky' || cur.getAttribute('role') === 'dialog' || cur.getAttribute('aria-modal') === 'true') return cur;
      cur = cur.parentElement;
    }
    return null;
  }

  // Пустые полноэкранные fixed-слои (затемнение за окном)
  function hideMasks() {
    var all = document.querySelectorAll('div');
    var vw = window.innerWidth, vh = window.innerHeight;
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      if (el.getAttribute('data-ct-hidden') || isOurs(el)) continue;
      if (el.children.length > 2 || (el.textContent || '').trim().length > 0) continue;
      if (window.getComputedStyle(el).position !== 'fixed') continue;
      var r = el.getBoundingClientRect();
      if (r.width < vw * 0.9 || r.height < vh * 0.9) continue;
      if (looksLikeCaptcha(el)) continue;
      hideEl(el, 'mask');
      log('mask hidden ' + desc(el));
    }
  }

  // Окно «Воспользуйтесь всеми функциями приложения» и подобные: нажимаем крестик и сразу прячем.
  // Если TikTok нарисует окно заново, его перехватит наблюдатель до отрисовки.
  function handlePopup(root) {
    if (!root || root.getAttribute('data-ct-hidden') || looksLikeCaptcha(root) || root.querySelector('video')) return false;
    // #streaming-root — служебный слой самой страницы (вместе с видео): прятать его нельзя
    if (root.id === 'streaming-root' || root.id === 'app' || (root.textContent || '').length > 1500) return false;
    var closers = root.querySelectorAll('[data-e2e*="close" i], [aria-label*="close" i], [aria-label*="закры" i], [class*="lose" i]');
    if (closers.length) { try { closers[0].click(); } catch (e) {} }
    hideEl(root, 'popup');
    if (POPUPS.length > 3) POPUPS.shift();
    POPUPS.push(desc(root) + ' html=' + root.outerHTML.replace(/\s+/g, ' ').slice(0, 1200));
    log('popup hidden ' + desc(root) + (closers.length ? ' (click close)' : ''));
    hideMasks();
    return true;
  }

  function findLeaf(root, re) {
    var list = root.querySelectorAll('*');
    for (var i = 0; i < list.length; i++) {
      var el = list[i];
      if (el.children.length > 3) continue;
      var t = (el.textContent || '').trim();
      if (t && t.length < 400 && re.test(t)) return el;
    }
    return null;
  }

  function scanAdded(n) {
    if (n.nodeType !== 1 || isOurs(n)) return;
    var t = n.textContent || '';
    if (!t || t.length > 3000 || !POPUP_RE.test(t)) return;
    var leaf = (n.children.length <= 3 && t.length < 400) ? n : findLeaf(n, POPUP_RE);
    var root = (leaf && fixedAncestor(leaf)) || fixedAncestor(n);
    if (root) handlePopup(root);
  }

  function endCardRoot(leaf, v) {
    var cur = leaf;
    for (var i = 0; i < 8 && cur.parentElement && cur.parentElement !== document.body; i++) {
      if (v && cur.parentElement.contains(v)) break;
      cur = cur.parentElement;
    }
    return (v && cur.contains(v)) ? null : cur;
  }

  function recRoot(h, v) {
    var cur = h;
    while (cur.parentElement && !cur.parentElement.contains(v) && cur.parentElement !== document.body) cur = cur.parentElement;
    return cur.contains(v) ? null : cur;
  }

  // Один проход по странице: баннеры, окна, cookies, экран конца ролика, рекомендации
  function textScan() {
    var v = isVideoPage() ? mainVideo() : null;
    var nodes = document.querySelectorAll('a, button, div, span, p, h1, h2, h3, section, aside');
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      if (el.children.length > 3 || el.getAttribute('data-ct-hidden') || isOurs(el)) continue;
      var txt = (el.textContent || '').trim();
      if (!txt || txt.length > 400) continue;
      if (el.closest('[data-ct-hidden]')) continue;

      if (txt.length < 70 && BANNER_RE.test(txt)) {
        var bc = bannerContainer(el);
        hideEl(bc, 'banner');
        log('banner hidden ' + desc(bc));
      } else if (POPUP_RE.test(txt)) {
        var root = fixedAncestor(el);
        if (root) handlePopup(root);
      } else if (COOKIE_RE.test(txt) && txt.length < 300) {
        var fx = fixedAncestor(el);
        if (fx && !fx.querySelector('video') && !looksLikeCaptcha(fx)) { hideEl(fx, 'cookie'); log('cookie hidden ' + desc(fx)); }
      } else if (!DESKTOP && v && ENDCARD_RE.test(txt)) {
        var ec = endCardRoot(el, v);
        if (ec) { hideEl(ec, 'endcard'); log('endcard hidden ' + desc(ec)); }
      } else if (!DESKTOP && v && el.children.length === 0 && txt.length < 60 && REC_RE.test(txt)) {
        var rr = recRoot(el, v);
        if (rr) {
          for (var s = rr; s; s = s.nextElementSibling) {
            if (!s.contains(v) && !isOurs(s)) hideEl(s, 'rec');
          }
          log('recommendations hidden');
        }
      }
    }
  }

  // ───────────────────────── Маршрут: классы, раскладка, сброс ─────────────────────────
  var lastHref = '';
  function applyRoute() {
    var de = document.documentElement;
    if (!de) return;
    var video = isVideoPage();
    de.classList.toggle('ct-video', video && !DESKTOP);
    de.classList.toggle('ct-desktop', DESKTOP);
    de.classList.toggle('ct-mobile', !DESKTOP);
    if (location.href !== lastHref) {
      lastHref = location.href;
      log('route ' + location.pathname);
      if (!video) unlayout();
      startedAt = Date.now();
    }
    if (DESKTOP && viewportWanted) setViewport(viewportWanted);
  }

  function light() {
    if (!DESKTOP && isVideoPage()) {
      var v = mainVideo();
      if (v) layoutPlayer(v);
    }
  }

  function sweep() {
    ensureStyle();
    applyRoute();
    textScan();
    if (isVideoPage()) {
      var v = mainVideo();
      if (v) {
        if (DESKTOP) { hideOtherFeedItems(v); fitDesktop(false); } else layoutPlayer(v);
      }
    }
  }
  window.__cleanTokSweep = sweep;

  var sweepTimer = null, lightTimer = null;
  function scheduleSweep() {
    if (sweepTimer) return;
    sweepTimer = setTimeout(function () { sweepTimer = null; try { sweep(); } catch (e) { log('ERR sweep ' + e); } }, 800);
  }
  function scheduleLight() {
    if (lightTimer) return;
    lightTimer = setTimeout(function () { lightTimer = null; try { light(); } catch (e) {} }, 250);
  }

  function onMutations(recs) {
    var structural = false, attr = false;
    for (var i = 0; i < recs.length; i++) {
      var r = recs[i];
      if (isOurs(r.target)) continue;
      if (r.type === 'childList') {
        structural = true;
        for (var j = 0; j < r.addedNodes.length; j++) {
          try { scanAdded(r.addedNodes[j]); } catch (e) {}
        }
      } else {
        attr = true;
      }
    }
    if (structural) { scheduleSweep(); scheduleLight(); }
    else if (attr) scheduleLight();
  }

  // ───────────────────────── Автоповтор загрузки, если плеер не появился ─────────────────────────
  var startedAt = Date.now();
  function checkLoaded() {
    if (!isVideoPage()) return;
    var v = mainVideo();
    if (v && (v.readyState >= 1 || v.videoWidth > 0)) {
      try { sessionStorage.removeItem('ctRetry'); } catch (e) {}
      return;
    }
    if (Date.now() - startedAt > 12000) {
      var n = 0;
      try { n = parseInt(sessionStorage.getItem('ctRetry') || '0', 10); } catch (e) {}
      if (n < 2) {
        try { sessionStorage.setItem('ctRetry', String(n + 1)); } catch (e) {}
        log('reload: video did not load');
        location.reload();
      }
    }
  }
  setInterval(checkLoaded, 2000);

  window.addEventListener('resize', function () { scheduleLight(); scheduleSweep(); });

  function start() {
    ensureStyle();
    try { sweep(); } catch (e) { log('ERR start ' + e); }
    new MutationObserver(onMutations).observe(document.documentElement, {
      childList: true,
      subtree: true
    });
    setInterval(function () { try { fitDesktop(false); light(); } catch (e) {} }, 1200);
    setInterval(function () { try { sweep(); } catch (e) {} }, 3000);
    setInterval(function () { try { applyRoute(); } catch (e) {} }, 400);
    log('started mode=' + (DESKTOP ? 'desktop' : 'mobile') + ' ' + location.href);
  }

  if (document.documentElement) {
    start();
  } else {
    document.addEventListener('DOMContentLoaded', start);
  }
})();
