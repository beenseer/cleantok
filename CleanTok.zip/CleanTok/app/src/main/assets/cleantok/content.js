(function () {
  'use strict';

  if (window.__cleanTokInstalled) {
    if (window.__cleanTokSweep) window.__cleanTokSweep();
    return;
  }
  window.__cleanTokInstalled = true;

  // В GeckoView скрипт расширения живёт в изолированном мире, страница доступна через wrappedJSObject
  var PAGE = window.wrappedJSObject || null;

  // ───────────────────────── Тёмная тема ─────────────────────────
  try { localStorage.setItem('tiktok_webapp_theme', 'dark'); } catch (e) {}
  try { document.cookie = 'tiktok_webapp_theme=dark; path=/; max-age=31536000'; } catch (e) {}

  // ───────────────────────── Работа в фоне: страница не должна знать, что она скрыта ─────────────────────────
  function defGetter(prop, value) {
    try {
      if (PAGE && typeof exportFunction === 'function') {
        Object.defineProperty(PAGE.document, prop, {
          get: exportFunction(function () { return value; }, window),
          configurable: true
        });
      } else {
        Object.defineProperty(document, prop, { get: function () { return value; }, configurable: true });
      }
    } catch (e) {}
  }
  defGetter('hidden', false);
  defGetter('webkitHidden', false);
  defGetter('visibilityState', 'visible');
  defGetter('webkitVisibilityState', 'visible');
  ['visibilitychange', 'webkitvisibilitychange'].forEach(function (name) {
    window.addEventListener(name, function (e) { e.stopImmediatePropagation(); }, true);
    document.addEventListener(name, function (e) { e.stopImmediatePropagation(); }, true);
  });

  // ───────────────────────── CSS ─────────────────────────
  var CSS = [
    'html { color-scheme: dark !important; background: #000 !important; }',
    'video { object-fit: contain !important; }',
    'a[href="/foryou"], a[href^="/foryou?"], a[href="/explore"], a[href="/following"],',
    '[data-e2e="nav-foryou"], [data-e2e="nav-explore"], [data-e2e="nav-following"] { display: none !important; }',
    '#ct-bar { position: fixed; left: 0; right: 0; bottom: 0; z-index: 2147483647; display: none;',
    '  align-items: center; gap: 10px; padding: 8px 12px calc(8px + env(safe-area-inset-bottom));',
    '  background: rgba(0,0,0,0.6); color: #fff; font: 14px/1 sans-serif; box-sizing: border-box; }',
    '#ct-pp { width: 40px; height: 40px; border: 0; border-radius: 20px; background: #25c7d9; color: #000; font-size: 16px; flex: none; }',
    '#ct-time { flex: none; min-width: 84px; text-align: center; font-variant-numeric: tabular-nums; }',
    '#ct-seek { flex: 1; min-width: 0; height: 32px; accent-color: #25c7d9; }',
    '#ct-badge { position: fixed; top: 18%; left: 50%; transform: translateX(-50%); z-index: 2147483647;',
    '  display: none; padding: 6px 14px; border-radius: 16px; background: rgba(0,0,0,0.65); color: #fff; font: bold 16px sans-serif; }'
  ].join('\n');

  function ensureStyle() {
    var root = document.head || document.documentElement;
    if (!root || document.getElementById('__cleantok_style')) return;
    var el = document.createElement('style');
    el.id = '__cleantok_style';
    el.textContent = CSS;
    root.appendChild(el);
  }

  // ───────────────────────── Вспомогательное ─────────────────────────
  function isVideoPage() { return /\/(video|photo)\//.test(location.pathname); }

  function mainVideo() {
    var vs = document.getElementsByTagName('video');
    var best = null, area = 0;
    for (var i = 0; i < vs.length; i++) {
      var r = vs[i].getBoundingClientRect();
      var a = r.width * r.height;
      if (a > area) { area = a; best = vs[i]; }
    }
    return best;
  }

  function inBar(t) { return !!(t && t.closest && t.closest('#ct-bar')); }

  function inScrollable(el) {
    var n = el, depth = 0;
    while (n && n !== document.body && n !== document.documentElement && depth < 20) {
      var cs = window.getComputedStyle(n);
      if ((cs.overflowY === 'auto' || cs.overflowY === 'scroll') && n.scrollHeight > n.clientHeight + 2) return true;
      n = n.parentElement;
      depth++;
    }
    return false;
  }

  function pointInVideo(t, v) {
    var r = v.getBoundingClientRect();
    return t.clientX >= r.left && t.clientX <= r.right && t.clientY >= r.top && t.clientY <= r.bottom;
  }

  function hideEl(el, kind) {
    el.style.setProperty('display', 'none', 'important');
    el.setAttribute('data-ct-hidden', kind || '1');
  }

  function fmt(s) {
    if (!isFinite(s) || s < 0) s = 0;
    var m = Math.floor(s / 60), sec = Math.floor(s % 60);
    return m + ':' + (sec < 10 ? '0' : '') + sec;
  }

  // ───────────────────────── Скорость 2×: зажать у края; зажать и свайпнуть вниз — включить/выключить насовсем ─────────────────────────
  var pressTimer = null, speedActive = false, speedLocked = false, speedTouched = false;
  var startX = 0, startY = 0, toggledThisPress = false, swallowClickUntil = 0;
  var badge = null;

  function showBadge() {
    if (!badge) {
      badge = document.createElement('div');
      badge.id = 'ct-badge';
      (document.documentElement).appendChild(badge);
    }
    if (speedActive || speedLocked) {
      badge.textContent = speedLocked ? '2× (закреплено)' : '2×';
      badge.style.display = 'block';
    } else {
      badge.style.display = 'none';
    }
  }

  function applySpeed() {
    var v = mainVideo();
    if (!v) return;
    var want = (speedActive || speedLocked) ? 2 : 1;
    if (want === 2) {
      speedTouched = true;
      if (v.playbackRate !== 2) v.playbackRate = 2;
    } else if (speedTouched) {
      if (v.playbackRate !== 1) v.playbackRate = 1;
      speedTouched = false;
    }
  }

  function buzz() { try { if (navigator.vibrate) navigator.vibrate(15); } catch (e) {} }

  function cancelPress() {
    if (pressTimer) { clearTimeout(pressTimer); pressTimer = null; }
  }

  window.addEventListener('touchstart', function (e) {
    cancelPress();
    if (!isVideoPage() || e.touches.length !== 1 || inBar(e.target)) return;
    var v = mainVideo();
    if (!v) return;
    var t = e.touches[0];
    if (!pointInVideo(t, v)) return;
    var r = v.getBoundingClientRect();
    var edge = r.width * 0.2;
    if (t.clientX > r.left + edge && t.clientX < r.right - edge) return;
    startX = t.clientX;
    startY = t.clientY;
    toggledThisPress = false;
    pressTimer = setTimeout(function () {
      pressTimer = null;
      speedActive = true;
      applySpeed();
      showBadge();
      buzz();
    }, 450);
  }, { passive: true, capture: true });

  window.addEventListener('touchmove', function (e) {
    var t = e.touches && e.touches[0];

    // Режим 2×: палец удерживается, ведём вниз — переключаем закрепление
    if (speedActive) {
      if (e.cancelable) e.preventDefault();
      e.stopImmediatePropagation();
      if (t && !toggledThisPress && t.clientY - startY > 70) {
        toggledThisPress = true;
        speedLocked = !speedLocked;
        showBadge();
        applySpeed();
        buzz();
      }
      return;
    }

    // Палец сдвинулся до срабатывания долгого нажатия — это обычный жест
    if (pressTimer && t && (Math.abs(t.clientX - startX) > 12 || Math.abs(t.clientY - startY) > 12)) cancelPress();

    // Блокировка перелистывания ленты свайпом по самому видео (комментарии и профиль листаются)
    if (!isVideoPage() || !t || inBar(e.target) || inScrollable(e.target)) return;
    var v = mainVideo();
    if (v && pointInVideo(t, v)) {
      if (e.cancelable) e.preventDefault();
      e.stopImmediatePropagation();
    }
  }, { passive: false, capture: true });

  function endPress() {
    cancelPress();
    if (speedActive) {
      speedActive = false;
      swallowClickUntil = Date.now() + 400;
      applySpeed();
      showBadge();
    }
  }
  window.addEventListener('touchend', endPress, { passive: true, capture: true });
  window.addEventListener('touchcancel', endPress, { passive: true, capture: true });

  window.addEventListener('contextmenu', function (e) {
    if (pressTimer || speedActive) e.preventDefault();
  }, true);

  window.addEventListener('click', function (e) {
    if (Date.now() < swallowClickUntil) { e.preventDefault(); e.stopImmediatePropagation(); return; }
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a) return;
    var href = a.getAttribute('href') || '';
    var blocked = /^(\/|\/foryou|\/explore|\/following|\/login|\/signup|\/download)(\?|#|$)/.test(href);
    var external = /^(https?:)?\/\//i.test(href) && !/^(https?:)?\/\/([a-z0-9-]+\.)*tiktok\.com(\/|$)/i.test(href);
    if (blocked || external || /^(intent|market|snssdk\d*):/i.test(href)) {
      e.preventDefault();
      e.stopImmediatePropagation();
    }
  }, true);

  setInterval(function () { if (speedActive || speedLocked || speedTouched) applySpeed(); }, 500);

  // ───────────────────────── Панель: пауза и перемотка ─────────────────────────
  var bar = null, pp = null, timeEl = null, seek = null, dragging = false;

  function buildBar() {
    if (bar && bar.isConnected) return;
    bar = document.createElement('div');
    bar.id = 'ct-bar';
    pp = document.createElement('button');
    pp.id = 'ct-pp';
    pp.type = 'button';
    timeEl = document.createElement('span');
    timeEl.id = 'ct-time';
    seek = document.createElement('input');
    seek.id = 'ct-seek';
    seek.type = 'range';
    seek.min = '0';
    seek.max = '1000';
    seek.step = '1';
    seek.value = '0';
    bar.appendChild(pp);
    bar.appendChild(timeEl);
    bar.appendChild(seek);
    document.documentElement.appendChild(bar);

    ['touchstart', 'touchend', 'click', 'pointerdown', 'mousedown'].forEach(function (n) {
      bar.addEventListener(n, function (e) { e.stopPropagation(); });
    });

    pp.addEventListener('click', function () {
      var v = mainVideo();
      if (!v) return;
      if (v.paused) { v.__ctUserPaused = false; v.play(); } else { v.__ctUserPaused = true; v.pause(); }
      updateBar();
    });
    seek.addEventListener('touchstart', function () { dragging = true; });
    seek.addEventListener('pointerdown', function () { dragging = true; });
    seek.addEventListener('input', function () {
      var v = mainVideo();
      if (v && isFinite(v.duration)) {
        v.currentTime = (seek.value / 1000) * v.duration;
        timeEl.textContent = fmt(v.currentTime) + ' / ' + fmt(v.duration);
      }
    });
    seek.addEventListener('change', function () { dragging = false; });
    seek.addEventListener('touchend', function () { dragging = false; });
    seek.addEventListener('pointerup', function () { dragging = false; });
  }

  function updateBar() {
    var v = isVideoPage() ? mainVideo() : null;
    buildBar();
    if (!v) { bar.style.display = 'none'; return; }
    bar.style.display = 'flex';
    pp.textContent = v.paused ? '▶' : '❚❚';
    if (!dragging) {
      var d = v.duration;
      if (isFinite(d) && d > 0) seek.value = String(Math.round((v.currentTime / d) * 1000));
      timeEl.textContent = fmt(v.currentTime) + ' / ' + fmt(d);
    }
    // Автозапуск один раз на ролик
    if (v.paused && !v.__ctUserPaused && !v.__ctAutoTried && v.readyState >= 2) {
      v.__ctAutoTried = true;
      try { var p = v.play(); if (p && p.catch) p.catch(function () {}); } catch (e) {}
    }
  }
  setInterval(function () { try { updateBar(); } catch (e) {} }, 300);

  // ───────────────────────── Зачистка баннеров, окон и рекомендаций ─────────────────────────
  var BANNER_RE = /^(открыть\s+(в\s+)?прил|открыть\s+tiktok|смотреть\s+в\s+tiktok|скачать|использовать приложение|продолжить в приложении|open\s+(in\s+)?app|open tiktok|watch\s+(this\s+)?(video\s+)?(in|on)\s+tiktok|get app|download|continue in app)/i;
  var REC_RE = /^(вам может понравиться|вам могут понравиться|you may like|more to explore|recommended|похожие видео|related videos)/i;
  var POPUP_RE = /(воспользуйтесь всеми функциями|use all (the )?(app )?features|в приложении вас ждет|get the full (tiktok )?experience|продолжить в приложении|войдите в tiktok|log in to tiktok|sign up for tiktok)/i;
  var COOKIE_RE = /(cookie|куки)/i;
  var CAPTCHA_RE = /(captcha|verify|капч|проверк[аи])/i;

  function looksLikeCaptcha(el) {
    var meta = (el.id || '') + ' ' + (typeof el.className === 'string' ? el.className : '');
    if (CAPTCHA_RE.test(meta)) return true;
    if (el.querySelector && el.querySelector('iframe, [class*="aptcha"], [id*="aptcha"]')) return true;
    return false;
  }

  function bannerContainer(leaf) {
    var best = leaf, cur = leaf;
    for (var i = 0; i < 6; i++) {
      var p = cur.parentElement;
      if (!p || p === document.body || p === document.documentElement) break;
      if (p.querySelector('video')) break;
      if (p.offsetHeight > window.innerHeight * 0.25) break;
      best = p;
      cur = p;
    }
    return best;
  }

  function fixedAncestor(el) {
    var cur = el;
    for (var i = 0; i < 12 && cur && cur !== document.body && cur !== document.documentElement; i++) {
      var cs = window.getComputedStyle(cur);
      if (cs.position === 'fixed' || cs.position === 'sticky' || cur.getAttribute('role') === 'dialog' || cur.getAttribute('aria-modal') === 'true') return cur;
      cur = cur.parentElement;
    }
    return null;
  }

  // Закрываем окно кнопкой-крестиком; если не получилось — прячем
  function dismissPopup(root) {
    if (root.getAttribute('data-ct-hidden') || looksLikeCaptcha(root)) return;
    if (root.getAttribute('data-ct-try')) { hideEl(root, 'popup'); return; }
    root.setAttribute('data-ct-try', '1');
    var closers = root.querySelectorAll('[data-e2e*="close" i], [aria-label*="close" i], [aria-label*="закры" i], [class*="lose" i]');
    if (closers.length) {
      try { closers[0].click(); } catch (e) { hideEl(root, 'popup'); }
    } else {
      hideEl(root, 'popup');
    }
  }

  // Тёмная подложка за окном: полноэкранный fixed-слой без видео
  function hideMasks() {
    var all = document.querySelectorAll('div');
    var vw = window.innerWidth, vh = window.innerHeight;
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      if (el.getAttribute('data-ct-hidden') || el.id === 'ct-bar' || el.id === 'ct-badge') continue;
      var cs = window.getComputedStyle(el);
      if (cs.position !== 'fixed') continue;
      var r = el.getBoundingClientRect();
      if (r.width < vw * 0.9 || r.height < vh * 0.9) continue;
      if (el.querySelector('video') || looksLikeCaptcha(el)) continue;
      hideEl(el, 'popup');
    }
  }

  function hideRecommendations(v) {
    var heads = document.querySelectorAll('h1, h2, h3, h4, div, span, p');
    for (var i = 0; i < heads.length; i++) {
      var h = heads[i];
      if (h.children.length > 0 || h.getAttribute('data-ct-hidden')) continue;
      var txt = (h.textContent || '').trim();
      if (!txt || txt.length > 60 || !REC_RE.test(txt)) continue;
      var cur = h;
      while (cur.parentElement && !cur.parentElement.contains(v) && cur.parentElement !== document.body) cur = cur.parentElement;
      if (cur.contains(v)) continue;
      for (var s = cur; s; s = s.nextElementSibling) {
        if (!s.contains(v) && s.id !== 'ct-bar' && s.id !== 'ct-badge') hideEl(s, 'rec');
      }
    }
  }

  function sweep() {
    ensureStyle();
    var popupSeen = !!document.querySelector('[data-ct-hidden="popup"], [data-ct-try]');

    var nodes = document.querySelectorAll('a, button, div, span, p, h1, h2, h3, section, aside');
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      if (el.getAttribute('data-ct-hidden') || el.children.length > 3) continue;
      var txt = (el.textContent || '').trim();
      if (!txt || txt.length > 400) continue;
      if (el.closest('[data-ct-hidden]') || el.closest('#ct-bar')) continue;

      if (txt.length < 70 && BANNER_RE.test(txt)) {
        hideEl(bannerContainer(el), 'banner');
      } else if (POPUP_RE.test(txt)) {
        var root = fixedAncestor(el);
        if (root && !root.querySelector('video')) { dismissPopup(root); popupSeen = true; }
      } else if (COOKIE_RE.test(txt) && txt.length < 300) {
        var fx = fixedAncestor(el);
        if (fx && !fx.querySelector('video') && !looksLikeCaptcha(fx)) hideEl(fx, 'cookie');
      }
    }

    if (popupSeen) hideMasks();

    if (isVideoPage()) {
      var v = mainVideo();
      if (v) hideRecommendations(v);
      // Страница ролика не должна листаться сама, пока мы не в комментариях
      document.documentElement.style.setProperty('overscroll-behavior', 'none', 'important');
    }
  }
  window.__cleanTokSweep = sweep;

  var timer = null;
  function schedule() {
    if (timer) return;
    timer = setTimeout(function () {
      timer = null;
      try { sweep(); } catch (e) {}
    }, 400);
  }

  // ───────────────────────── Автоповтор загрузки, если плеер не появился ─────────────────────────
  var startedAt = Date.now();
  function checkLoaded() {
    if (!isVideoPage()) return;
    var v = mainVideo();
    if (v && (v.readyState >= 1 || v.videoWidth > 0)) {
      try { sessionStorage.removeItem('ctRetry'); } catch (e) {}
      return;
    }
    if (Date.now() - startedAt > 10000) {
      var n = 0;
      try { n = parseInt(sessionStorage.getItem('ctRetry') || '0', 10); } catch (e) {}
      if (n < 2) {
        try { sessionStorage.setItem('ctRetry', String(n + 1)); } catch (e) {}
        location.reload();
      }
    }
  }
  setInterval(checkLoaded, 2000);

  function start() {
    ensureStyle();
    try { sweep(); } catch (e) {}
    new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true });
    setInterval(function () { try { sweep(); } catch (e) {} }, 1500);
  }

  if (document.documentElement) {
    start();
  } else {
    document.addEventListener('DOMContentLoaded', start);
  }
})();
