(function () {
  'use strict';

  if (window.__cleanTokInstalled) {
    if (window.__cleanTokSweep) window.__cleanTokSweep();
    return;
  }
  window.__cleanTokInstalled = true;

  // ───────── CSS (минимум, чтобы не сломать плеер) ─────────
  var CSS = [
    'html, body { overflow: hidden !important; overscroll-behavior: none !important; }',
    'a[href="/foryou"], a[href^="/foryou?"], a[href="/explore"], a[href="/following"],',
    '[data-e2e="nav-foryou"], [data-e2e="nav-explore"], [data-e2e="nav-following"] { display: none !important; }'
  ].join('\n');

  function ensureStyle() {
    var root = document.head || document.documentElement;
    if (!root) return;
    if (!document.getElementById('__cleantok_style')) {
      var el = document.createElement('style');
      el.id = '__cleantok_style';
      el.textContent = CSS;
      root.appendChild(el);
    }
  }

  // ───────── Блокировка скролла/свайпов ─────────
  function isSlider(t) {
    return !!(t && t.closest && t.closest('input[type="range"], [role="slider"]'));
  }
  function lockScroll(e) {
    if (isSlider(e.target)) return;
    if (e.cancelable) e.preventDefault();
  }
  document.addEventListener('touchmove', lockScroll, { passive: false, capture: true });
  document.addEventListener('wheel', lockScroll, { passive: false, capture: true });
  document.addEventListener('keydown', function (e) {
    if ([33, 34, 35, 36, 38, 40].indexOf(e.keyCode) >= 0) {
      e.preventDefault();
      e.stopPropagation();
    }
  }, true);

  // ───────── Блокировка переходов, кроме самих роликов ─────────
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a) return;
    var href = a.getAttribute('href') || '';
    if (/\/(video|photo)\//.test(href)) return;
    e.preventDefault();
    e.stopPropagation();
  }, true);

  // ───────── Зачистка баннеров по тексту ─────────
  var BANNER_RE = /^(открыть\s+(в\s+)?прил|открыть\s+tiktok|скачать|использовать приложение|продолжить в приложении|open app|open in app|open tiktok|get app|download|continue in app)/i;
  var COOKIE_RE = /(cookie|куки|файлы cookie)/i;
  var LOGIN_RE = /(войти|log in|sign up|зарегистр|продолжить с|continue with|вход в)/i;

  function hideEl(el) {
    el.style.setProperty('display', 'none', 'important');
    el.setAttribute('data-ct-hidden', '1');
  }

  // Поднимаемся от кнопки к контейнеру баннера, но не захватываем плеер
  function bannerContainer(leaf) {
    var best = leaf;
    var cur = leaf;
    for (var i = 0; i < 6; i++) {
      var p = cur.parentElement;
      if (!p || p === document.body || p === document.documentElement) break;
      if (p.querySelector('video')) break;
      if (p.offsetHeight > window.innerHeight * 0.25) break;
      best = p;
      cur = p;
    }
    return best;
  }

  function fixedAncestor(el) {
    var cur = el;
    for (var i = 0; i < 5 && cur && cur !== document.body; i++) {
      var pos = window.getComputedStyle(cur).position;
      if (pos === 'fixed' || pos === 'sticky') return cur;
      cur = cur.parentElement;
    }
    return null;
  }

  function sweep() {
    ensureStyle();

    var nodes = document.querySelectorAll('a, button, div, span, p, section, aside');
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      if (el.getAttribute('data-ct-hidden')) continue;
      if (el.children.length > 3) continue;
      var txt = (el.textContent || '').trim();
      if (!txt || txt.length > 300) continue;
      if (el.closest('[data-ct-hidden]')) continue;

      if (txt.length < 60 && BANNER_RE.test(txt)) {
        hideEl(bannerContainer(el));
      } else if (COOKIE_RE.test(txt)) {
        var fx = fixedAncestor(el);
        if (fx && !fx.querySelector('video')) hideEl(fx);
      }
    }

    // Модальные окна входа и т.п.
    var dialogs = document.querySelectorAll('dialog, [role="dialog"], [aria-modal="true"]');
    for (var j = 0; j < dialogs.length; j++) {
      var d = dialogs[j];
      if (d.getAttribute('data-ct-hidden')) continue;
      if (d.querySelector('video')) continue;
      var t = (d.textContent || '');
      if (LOGIN_RE.test(t) || COOKIE_RE.test(t) || BANNER_RE.test(t.trim())) hideEl(d);
    }

    if (document.body) document.body.style.setProperty('overflow', 'hidden', 'important');
    document.documentElement.style.setProperty('overflow', 'hidden', 'important');
  }

  window.__cleanTokSweep = sweep;

  var timer = null;
  function schedule() {
    if (timer) return;
    timer = setTimeout(function () {
      timer = null;
      try { sweep(); } catch (err) {}
    }, 400);
  }

  function start() {
    ensureStyle();
    try { sweep(); } catch (err) {}
    new MutationObserver(schedule).observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }

  if (document.documentElement) {
    start();
  } else {
    document.addEventListener('DOMContentLoaded', start);
  }
})();
