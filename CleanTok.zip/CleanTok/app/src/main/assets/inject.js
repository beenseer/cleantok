(function () {
  'use strict';

  if (window.__cleanTokInstalled) {
    if (window.__cleanTokSweep) window.__cleanTokSweep();
    return;
  }
  window.__cleanTokInstalled = true;

  // ───────── CSS ─────────
  var CSS = [
    'html, body { overflow: hidden !important; overscroll-behavior: none !important; height: 100% !important; }',
    // окна входа, «Открыть в приложении», баннеры, cookies
    '[data-e2e*="login"], [data-e2e*="modal"], [data-e2e*="cookie"], [data-e2e*="open-app"], [data-e2e*="download"],',
    '[id*="login-modal"], [id*="cookie"], [id*="open-app"],',
    '[class*="LoginContainer"], [class*="LoginModal"], [class*="login-modal"],',
    '[class*="OpenApp"], [class*="open-app"], [class*="AppBanner"], [class*="app-banner"],',
    '[class*="BannerContainer"], [class*="BottomBanner"], [class*="DownloadBanner"],',
    '[class*="CookieBanner"], [class*="cookie-banner"], tiktok-cookie-banner,',
    '[class*="DivModalContainer"], [class*="DivGuestLogin"], [class*="PopupContainer"],',
    // кнопки перехода в ленту «Для вас»
    'a[href="/"], a[href="/foryou"], a[href^="/foryou?"], a[href="/explore"], a[href="/following"],',
    '[data-e2e="nav-foryou"], [data-e2e="nav-explore"], [data-e2e="nav-following"],',
    '[data-e2e="arrow-right"], [data-e2e="arrow-left"], [data-e2e="video-switch"] { display: none !important; }'
  ].join('\n');

  function ensureStyle() {
    var root = document.head || document.documentElement;
    if (!root) return;
    var el = document.getElementById('__cleantok_style');
    if (!el) {
      el = document.createElement('style');
      el.id = '__cleantok_style';
      el.textContent = CSS;
      root.appendChild(el);
    }
  }

  // ───────── Блокировка скролла/свайпов ─────────
  function isSlider(t) {
    return !!(t && t.closest && t.closest('input[type="range"], [role="slider"], [class*="Seek"], [class*="seek"], [class*="Progress"]'));
  }

  function lockScroll(e) {
    if (isSlider(e.target)) return;
    if (e.cancelable) e.preventDefault();
  }

  document.addEventListener('touchmove', lockScroll, { passive: false, capture: true });
  document.addEventListener('wheel', lockScroll, { passive: false, capture: true });
  document.addEventListener('keydown', function (e) {
    if ([33, 34, 35, 36, 38, 40].indexOf(e.keyCode) >= 0) {
      e.preventDefault();
      e.stopPropagation();
    }
  }, true);

  // ───────── Блокировка переходов по ссылкам, кроме самих роликов ─────────
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a) return;
    var href = a.getAttribute('href') || '';
    if (/\/(video|photo)\//.test(href)) return;
    e.preventDefault();
    e.stopPropagation();
  }, true);

  // ───────── Текстовая зачистка оверлеев ─────────
  var TEXT_RE = /(открыть в приложении|открыть tiktok|скачать|войти|вход|регистрац|cookie|куки|принять все|open app|open in app|open tiktok|get app|download|log in|sign up|continue in app|accept all)/i;

  function sweep() {
    ensureStyle();
    var nodes = document.querySelectorAll('div, section, aside, header, footer, nav, dialog, [role="dialog"]');
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      if (el.getAttribute('data-ct-hidden')) continue;
      var isDialog = el.tagName === 'DIALOG' ||
        el.getAttribute('role') === 'dialog' ||
        el.getAttribute('aria-modal') === 'true';
      if (!isDialog) {
        var pos = window.getComputedStyle(el).position;
        if (pos !== 'fixed' && pos !== 'sticky') continue;
      }
      if (el.querySelector('video')) continue;
      var txt = (el.innerText || '').trim();
      if (isDialog || (txt.length > 0 && txt.length < 400 && TEXT_RE.test(txt))) {
        el.style.setProperty('display', 'none', 'important');
        el.setAttribute('data-ct-hidden', '1');
      }
    }
    if (document.body) {
      document.body.style.setProperty('overflow', 'hidden', 'important');
    }
    document.documentElement.style.setProperty('overflow', 'hidden', 'important');
  }

  window.__cleanTokSweep = sweep;

  var timer = null;
  function schedule() {
    if (timer) return;
    timer = setTimeout(function () {
      timer = null;
      try { sweep(); } catch (err) {}
    }, 400);
  }

  function start() {
    ensureStyle();
    try { sweep(); } catch (err) {}
    new MutationObserver(schedule).observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }

  if (document.documentElement) {
    start();
  } else {
    document.addEventListener('DOMContentLoaded', start);
  }
})();
