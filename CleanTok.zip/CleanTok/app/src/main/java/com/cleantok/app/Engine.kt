package com.cleantok.app

/** То, что движок просит у приложения */
interface EngineHost {
    /** Разрешён ли переход главного фрейма на этот адрес */
    fun isLoadAllowed(url: String, isRedirect: Boolean): Boolean

    fun onProgress(loading: Boolean)

    fun onFullscreen(enabled: Boolean)

    fun onFatal()
}

/** Общий интерфейс для WebView- и GeckoView-версий */
interface Engine {
    fun load(url: String)
    fun reload()
    fun canGoBack(): Boolean
    fun goBack()
    fun currentUrl(): String?

    /** Сбросить страницу и историю (при выходе на главный экран) */
    fun reset()

    fun exitFullscreen()
    fun onResume()
    fun destroy()
}

object Const {
    const val MOBILE_UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/142.0.0.0 Mobile Safari/537.36"
}
