package com.cleantok.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var home: View
    private lateinit var viewer: View
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private lateinit var fullscreenContainer: FrameLayout
    private lateinit var linkInput: EditText

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    private val executor = Executors.newSingleThreadExecutor()

    @Volatile
    private var requestId = 0

    /** true — ролик открыт по ссылке извне (Telegram и т.п.): «Назад» закрывает приложение */
    private var openedFromOutside = false

    private val injectJs: String by lazy {
        assets.open("inject.js").bufferedReader().use { it.readText() }
    }

    private val mobileUserAgent: String by lazy {
        try {
            WebSettings.getDefaultUserAgent(this)
                .replace("; wv", "")
                .replace("Version/4.0 ", "")
        } catch (e: Exception) {
            FALLBACK_UA
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        home = findViewById(R.id.home)
        viewer = findViewById(R.id.viewer)
        webView = findViewById(R.id.webView)
        progress = findViewById(R.id.progress)
        fullscreenContainer = findViewById(R.id.fullscreenContainer)
        linkInput = findViewById(R.id.linkInput)

        setupWebView()

        findViewById<Button>(R.id.btnSettings).setOnClickListener { openLinkSettings() }
        findViewById<Button>(R.id.btnOpen).setOnClickListener { openManualLink() }
        findViewById<ImageButton>(R.id.btnClose).setOnClickListener { closeViewer() }
        linkInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                openManualLink()
                true
            } else false
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> hideCustomView()
                    viewer.visibility == View.VISIBLE -> closeViewer()
                    else -> finish()
                }
            }
        })

        handleIntent(intent, isNewIntent = false)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent, isNewIntent = true)
    }

    override fun onPause() {
        super.onPause()
        webView.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onDestroy() {
        executor.shutdownNow()
        (webView.parent as? ViewGroup)?.removeView(webView)
        webView.destroy()
        super.onDestroy()
    }

    // ───────────────────────── Обработка интентов ─────────────────────────

    private fun handleIntent(intent: Intent?, isNewIntent: Boolean) {
        val raw = when (intent?.action) {
            Intent.ACTION_VIEW -> intent?.dataString
            Intent.ACTION_SEND -> intent?.getStringExtra(Intent.EXTRA_TEXT)
            else -> null
        }
        val url = raw?.let { extractTikTokUrl(it) }
        if (url != null) {
            openedFromOutside = true
            openLink(url)
        } else if (!isNewIntent) {
            if (raw != null) {
                Toast.makeText(this, R.string.not_tiktok_link, Toast.LENGTH_LONG).show()
            }
            showHome()
        }
        // Повторный тап по иконке при открытом ролике ничего не сбрасывает
    }

    private fun openManualLink() {
        val text = linkInput.text.toString().trim()
        hideKeyboard()
        val candidate = if (text.startsWith("http", ignoreCase = true)) text else "https://$text"
        val url = extractTikTokUrl(candidate) ?: extractTikTokUrl(text)
        if (url == null) {
            Toast.makeText(this, R.string.not_tiktok_link, Toast.LENGTH_LONG).show()
            return
        }
        openedFromOutside = false
        openLink(url)
    }

    private fun openLinkSettings() {
        val pkg = Uri.parse("package:$packageName")
        val intents = buildList {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                add(Intent(Settings.ACTION_APP_OPEN_BY_DEFAULT_SETTINGS, pkg))
            }
            add(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg))
        }
        for (i in intents) {
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
                // пробуем следующий вариант
            }
        }
    }

    // ───────────────────────── Ссылки ─────────────────────────

    private fun extractTikTokUrl(text: String): String? =
        URL_REGEX.findAll(text)
            .map { it.value.trimEnd('.', ',', ')', ']', '!', ';') }
            .firstOrNull { isTikTokHost(Uri.parse(it).host) }

    private fun isTikTokHost(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return h == "tiktok.com" || h.endsWith(".tiktok.com")
    }

    private fun isVideoUrl(url: String): Boolean {
        val path = Uri.parse(url).path ?: return false
        return path.contains("/video/") || path.contains("/photo/")
    }

    private fun needsResolve(url: String): Boolean {
        if (isVideoUrl(url)) return false
        val uri = Uri.parse(url)
        val host = uri.host?.lowercase() ?: return false
        val path = uri.path ?: ""
        return host.startsWith("vm.") || host.startsWith("vt.") || path.startsWith("/t/")
    }

    /** Принудительно https и обрезка всех GET-параметров и фрагмента */
    private fun cleanUrl(url: String): String {
        val noHttp = if (url.startsWith("http://", ignoreCase = true)) "https://" + url.substring(7) else url
        return noHttp.substringBefore('#').substringBefore('?')
    }

    private fun openLink(url: String) {
        showViewer()
        progress.visibility = View.VISIBLE
        val id = ++requestId

        if (needsResolve(url)) {
            executor.execute {
                val resolved = resolveRedirects(url)
                runOnUiThread {
                    if (id == requestId && !isDestroyed) webView.loadUrl(cleanUrl(resolved))
                }
            }
        } else {
            webView.loadUrl(cleanUrl(url))
        }
    }

    /** Проходит по редиректам короткой ссылки до полного URL ролика (/video/ID) */
    private fun resolveRedirects(start: String): String {
        var current = if (start.startsWith("http://", ignoreCase = true)) "https://" + start.substring(7) else start
        repeat(8) {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(current).openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", mobileUserAgent)
                    setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                }
                val code = conn.responseCode
                if (code in 300..399) {
                    val location = conn.getHeaderField("Location") ?: return current
                    current = URL(URL(current), location).toString()
                    if (isVideoUrl(current)) return current
                } else {
                    return current
                }
            } catch (e: Exception) {
                return current
            } finally {
                conn?.disconnect()
            }
        }
        return current
    }

    // ───────────────────────── UI ─────────────────────────

    private fun showHome() {
        home.visibility = View.VISIBLE
        viewer.visibility = View.GONE
    }

    private fun showViewer() {
        home.visibility = View.GONE
        viewer.visibility = View.VISIBLE
    }

    private fun closeViewer() {
        requestId++
        if (openedFromOutside) {
            finish()
        } else {
            webView.loadUrl("about:blank")
            showHome()
        }
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(linkInput.windowToken, 0)
    }

    private fun setFullscreenMode(enabled: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (enabled) {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    private fun hideCustomView() {
        val view = customView ?: return
        fullscreenContainer.removeView(view)
        fullscreenContainer.visibility = View.GONE
        customViewCallback?.onCustomViewHidden()
        customView = null
        customViewCallback = null
        setFullscreenMode(false)
    }

    // ───────────────────────── WebView ─────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        webView.setBackgroundColor(Color.BLACK)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            userAgentString = mobileUserAgent
            useWideViewPort = true
            loadWithOverviewMode = false
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }

        webView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme?.lowercase()

                // intent://, snssdk1233://, market:// и прочие внешние схемы — блокируем
                if (scheme != "http" && scheme != "https") return true
                if (!request.isForMainFrame) return false

                if (!isTikTokHost(uri.host)) return true

                val path = uri.path ?: ""
                val isFeed = path.isEmpty() || path == "/" ||
                    path.startsWith("/foryou") || path.startsWith("/explore") ||
                    path.startsWith("/following") || path.startsWith("/discover")
                if (isFeed) return true

                // Переходы по ссылкам на не-видео страницы (профили, логин и т.д.) блокируем,
                // серверные редиректы пропускаем, чтобы не сломать загрузку ролика.
                if (!request.isRedirect && !isVideoUrl(uri.toString())) return true
                return false
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                view.evaluateJavascript(injectJs, null)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                view.evaluateJavascript(injectJs, null)
                progress.visibility = View.GONE
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                if (request.isForMainFrame) {
                    progress.visibility = View.GONE
                    Toast.makeText(this@MainActivity, R.string.load_error, Toast.LENGTH_LONG).show()
                }
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                Toast.makeText(this@MainActivity, R.string.load_error, Toast.LENGTH_LONG).show()
                finish()
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {

            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                fullscreenContainer.addView(
                    view,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                fullscreenContainer.visibility = View.VISIBLE
                setFullscreenMode(true)
            }

            override fun onHideCustomView() {
                hideCustomView()
            }

            // Всплывающие окна запрещены
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean = false
        }
    }

    companion object {
        private val URL_REGEX = Regex("""https?://[^\s<>"']+""", RegexOption.IGNORE_CASE)

        private const val FALLBACK_UA =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/142.0.0.0 Mobile Safari/537.36"
    }
}
