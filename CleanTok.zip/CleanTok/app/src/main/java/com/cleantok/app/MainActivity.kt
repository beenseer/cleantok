package com.cleantok.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity(), EngineHost {

    private lateinit var home: View
    private lateinit var viewer: View
    private lateinit var progress: ProgressBar
    private lateinit var btnClose: ImageButton
    private lateinit var controls: LinearLayout
    private lateinit var linkInput: EditText
    private lateinit var fullscreenContainer: FrameLayout
    private lateinit var engine: Engine

    private val executor = Executors.newSingleThreadExecutor()

    @Volatile
    private var requestId = 0

    /** true — ролик открыт по ссылке извне (Telegram и т.п.): «Назад» закрывает приложение */
    private var openedFromOutside = false
    private var isFullscreen = false
    private var lastOpened: String? = null
    private var askedNotifications = false

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Тёмная тема всегда
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        home = findViewById(R.id.home)
        viewer = findViewById(R.id.viewer)
        progress = findViewById(R.id.progress)
        btnClose = findViewById(R.id.btnClose)
        controls = findViewById(R.id.controls)
        linkInput = findViewById(R.id.linkInput)
        fullscreenContainer = findViewById(R.id.fullscreenContainer)

        engine = EngineFactory.create(this, findViewById(R.id.engineContainer), fullscreenContainer, this)

        findViewById<Button>(R.id.btnSettings).setOnClickListener { openLinkSettings() }
        findViewById<Button>(R.id.btnOpen).setOnClickListener { openManualLink() }
        findViewById<ImageButton>(R.id.btnShare).setOnClickListener { shareCurrent() }
        findViewById<ImageButton>(R.id.btnReload).setOnClickListener { engine.reload() }
        btnClose.setOnClickListener { closeViewer() }
        linkInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                openManualLink()
                true
            } else false
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    isFullscreen -> engine.exitFullscreen()
                    viewer.visibility == View.VISIBLE ->
                        if (engine.canGoBack()) engine.goBack() else closeViewer()
                    else -> finish()
                }
            }
        })

        handleIntent(intent, isNewIntent = false)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent, isNewIntent = true)
    }

    override fun onResume() {
        super.onResume()
        engine.onResume()
    }

    override fun onDestroy() {
        executor.shutdownNow()
        stopPlaybackService()
        engine.destroy()
        super.onDestroy()
    }

    // ───────────────────────── EngineHost ─────────────────────────

    override fun isLoadAllowed(url: String, isRedirect: Boolean): Boolean {
        if (url == "about:blank") return true
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase()
        // intent://, snssdk1233://, market:// и прочие внешние схемы — блокируем
        if (scheme != "http" && scheme != "https") return false
        if (!isTikTokHost(uri.host)) return false

        val path = uri.path ?: ""
        val blocked = path.isEmpty() || path == "/" || BLOCKED_PREFIXES.any { path.startsWith(it) }
        if (blocked) return false

        // Ролики, профили авторов и серверные редиректы (короткие ссылки) пропускаем
        return isRedirect || path.startsWith("/@") || isVideoUrl(url) || isShortLink(uri)
    }

    override fun onProgress(loading: Boolean) {
        runOnUiThread { progress.visibility = if (loading) View.VISIBLE else View.GONE }
    }

    override fun onFullscreen(enabled: Boolean) {
        runOnUiThread {
            isFullscreen = enabled
            setFullscreenMode(enabled)
            val v = if (enabled) View.GONE else View.VISIBLE
            btnClose.visibility = v
            controls.visibility = v
        }
    }

    override fun onFatal() {
        runOnUiThread {
            Toast.makeText(this, R.string.load_error, Toast.LENGTH_LONG).show()
            finish()
        }
    }

    // ───────────────────────── Обработка интентов ─────────────────────────

    private fun handleIntent(intent: Intent?, isNewIntent: Boolean) {
        val raw = when (intent?.action) {
            Intent.ACTION_VIEW -> intent?.dataString
            Intent.ACTION_SEND -> intent?.getStringExtra(Intent.EXTRA_TEXT)
            else -> null
        }
        val url = raw?.let { extractTikTokUrl(it) }
        if (url != null) {
            openedFromOutside = true
            openLink(url)
        } else if (!isNewIntent) {
            if (raw != null) {
                Toast.makeText(this, R.string.not_tiktok_link, Toast.LENGTH_LONG).show()
            }
            showHome()
        }
        // Повторный тап по иконке (или по уведомлению) при открытом ролике ничего не сбрасывает
    }

    private fun openManualLink() {
        val text = linkInput.text.toString().trim()
        hideKeyboard()
        val candidate = if (text.startsWith("http", ignoreCase = true)) text else "https://$text"
        val url = extractTikTokUrl(candidate) ?: extractTikTokUrl(text)
        if (url == null) {
            Toast.makeText(this, R.string.not_tiktok_link, Toast.LENGTH_LONG).show()
            return
        }
        openedFromOutside = false
        openLink(url)
    }

    private fun openLinkSettings() {
        val pkg = Uri.parse("package:$packageName")
        val intents = buildList {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                add(Intent(Settings.ACTION_APP_OPEN_BY_DEFAULT_SETTINGS, pkg))
            }
            add(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg))
        }
        for (i in intents) {
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
                // пробуем следующий вариант
            }
        }
    }

    private fun shareCurrent() {
        val current = engine.currentUrl()
        val url = if (current != null && isTikTokHost(Uri.parse(current).host)) cleanUrl(current) else lastOpened
        if (url == null) return
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, url)
        }
        startActivity(Intent.createChooser(send, getString(R.string.share)))
    }

    // ───────────────────────── Ссылки ─────────────────────────

    private fun extractTikTokUrl(text: String): String? =
        URL_REGEX.findAll(text)
            .map { it.value.trimEnd('.', ',', ')', ']', '!', ';') }
            .firstOrNull { isTikTokHost(Uri.parse(it).host) }

    private fun isTikTokHost(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return h == "tiktok.com" || h.endsWith(".tiktok.com")
    }

    private fun isVideoUrl(url: String): Boolean {
        val path = Uri.parse(url).path ?: return false
        return path.contains("/video/") || path.contains("/photo/")
    }

    private fun isShortLink(uri: Uri): Boolean {
        val host = uri.host?.lowercase() ?: return false
        val path = uri.path ?: ""
        return host.startsWith("vm.") || host.startsWith("vt.") || path.startsWith("/t/")
    }

    private fun needsResolve(url: String): Boolean = !isVideoUrl(url) && isShortLink(Uri.parse(url))

    /** Принудительно https и обрезка всех GET-параметров и фрагмента */
    private fun cleanUrl(url: String): String {
        val noHttp = if (url.startsWith("http://", ignoreCase = true)) "https://" + url.substring(7) else url
        return noHttp.substringBefore('#').substringBefore('?')
    }

    private fun openLink(url: String) {
        showViewer()
        progress.visibility = View.VISIBLE
        startPlaybackService()
        val id = ++requestId

        if (needsResolve(url)) {
            executor.execute {
                val resolved = resolveRedirects(url)
                runOnUiThread {
                    if (id == requestId && !isDestroyed) {
                        lastOpened = cleanUrl(resolved)
                        engine.load(cleanUrl(resolved))
                    }
                }
            }
        } else {
            lastOpened = cleanUrl(url)
            engine.load(cleanUrl(url))
        }
    }

    /** Проходит по редиректам короткой ссылки до полного URL ролика (/video/ID) */
    private fun resolveRedirects(start: String): String {
        var current = if (start.startsWith("http://", ignoreCase = true)) "https://" + start.substring(7) else start
        repeat(8) {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(current).openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", Const.MOBILE_UA)
                    setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                }
                val code = conn.responseCode
                if (code in 300..399) {
                    val location = conn.getHeaderField("Location") ?: return current
                    current = URL(URL(current), location).toString()
                    if (isVideoUrl(current)) return current
                } else {
                    return current
                }
            } catch (e: Exception) {
                return current
            } finally {
                conn?.disconnect()
            }
        }
        return current
    }

    // ───────────────────────── Служба для фонового звука ─────────────────────────

    private fun startPlaybackService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !askedNotifications &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            askedNotifications = true
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        try {
            ContextCompat.startForegroundService(this, Intent(this, PlaybackService::class.java))
        } catch (e: Exception) {
            // без службы всё работает, просто звук в фоне может прерываться
        }
    }

    private fun stopPlaybackService() {
        stopService(Intent(this, PlaybackService::class.java))
    }

    // ───────────────────────── UI ─────────────────────────

    private fun showHome() {
        home.visibility = View.VISIBLE
        viewer.visibility = View.GONE
    }

    private fun showViewer() {
        home.visibility = View.GONE
        viewer.visibility = View.VISIBLE
    }

    private fun closeViewer() {
        requestId++
        stopPlaybackService()
        if (openedFromOutside) {
            finish()
        } else {
            engine.reset()
            showHome()
        }
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(linkInput.windowToken, 0)
    }

    private fun setFullscreenMode(enabled: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (enabled) {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    companion object {
        private val URL_REGEX = Regex("""https?://[^\s<>"']+""", RegexOption.IGNORE_CASE)

        private val BLOCKED_PREFIXES = listOf(
            "/foryou", "/explore", "/following", "/discover",
            "/login", "/signup", "/download", "/live", "/search"
        )
    }
}
