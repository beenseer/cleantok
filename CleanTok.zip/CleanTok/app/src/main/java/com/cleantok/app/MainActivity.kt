package com.cleantok.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.GeckoView
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var home: View
    private lateinit var viewer: View
    private lateinit var geckoView: GeckoView
    private lateinit var progress: ProgressBar
    private lateinit var btnClose: ImageButton
    private lateinit var linkInput: EditText

    private lateinit var session: GeckoSession

    private val executor = Executors.newSingleThreadExecutor()

    @Volatile
    private var requestId = 0

    /** true — ролик открыт по ссылке извне (Telegram и т.п.): «Назад» закрывает приложение */
    private var openedFromOutside = false

    /** Расширение (скрытие баннеров, блокировка скролла) должно быть установлено до загрузки страницы */
    private var extensionReady = false
    private var pendingUrl: String? = null

    private var isFullscreen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        home = findViewById(R.id.home)
        viewer = findViewById(R.id.viewer)
        geckoView = findViewById(R.id.geckoView)
        progress = findViewById(R.id.progress)
        btnClose = findViewById(R.id.btnClose)
        linkInput = findViewById(R.id.linkInput)

        setupGecko()

        findViewById<Button>(R.id.btnSettings).setOnClickListener { openLinkSettings() }
        findViewById<Button>(R.id.btnOpen).setOnClickListener { openManualLink() }
        btnClose.setOnClickListener { closeViewer() }
        linkInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                openManualLink()
                true
            } else false
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    isFullscreen -> session.exitFullScreen()
                    viewer.visibility == View.VISIBLE -> closeViewer()
                    else -> finish()
                }
            }
        })

        handleIntent(intent, isNewIntent = false)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent, isNewIntent = true)
    }

    override fun onResume() {
        super.onResume()
        session.setActive(true)
    }

    override fun onPause() {
        super.onPause()
        session.setActive(false)
    }

    override fun onDestroy() {
        executor.shutdownNow()
        session.close()
        super.onDestroy()
    }

    // ───────────────────────── GeckoView ─────────────────────────

    private fun setupGecko() {
        val rt = runtime ?: GeckoRuntime.create(applicationContext).also { runtime = it }

        val settings = GeckoSessionSettings.Builder()
            .usePrivateMode(false)
            .userAgentMode(GeckoSessionSettings.USER_AGENT_MODE_MOBILE)
            .viewportMode(GeckoSessionSettings.VIEWPORT_MODE_MOBILE)
            .build()

        session = GeckoSession(settings)

        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLoadRequest(
                session: GeckoSession,
                request: GeckoSession.NavigationDelegate.LoadRequest
            ): GeckoResult<AllowOrDeny>? {
                val allowed = isLoadAllowed(request.uri, request.isRedirect)
                return GeckoResult.fromValue(if (allowed) AllowOrDeny.ALLOW else AllowOrDeny.DENY)
            }

            // Всплывающие окна запрещены
            override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? = null
        }

        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                progress.visibility = View.VISIBLE
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                progress.visibility = View.GONE
            }

            override fun onProgressChange(session: GeckoSession, progressValue: Int) {
                progress.visibility = if (progressValue < 100) View.VISIBLE else View.GONE
            }
        }

        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
                isFullscreen = fullScreen
                setFullscreenMode(fullScreen)
                btnClose.visibility = if (fullScreen) View.GONE else View.VISIBLE
            }

            override fun onCrash(session: GeckoSession) {
                Toast.makeText(this@MainActivity, R.string.load_error, Toast.LENGTH_LONG).show()
                finish()
            }
        }

        session.open(rt)
        geckoView.setSession(session)

        // Встроенное расширение: скрывает баннеры и блокирует скролл. Страницы грузим только после его установки.
        rt.webExtensionController
            .ensureBuiltIn(EXTENSION_LOCATION, EXTENSION_ID)
            .accept(
                { _ -> onExtensionReady() },
                { _ -> onExtensionReady() }
            )
    }

    private fun onExtensionReady() {
        extensionReady = true
        pendingUrl?.let { session.loadUri(it) }
        pendingUrl = null
    }

    private fun load(url: String) {
        if (extensionReady) session.loadUri(url) else pendingUrl = url
    }

    private fun isLoadAllowed(url: String, isRedirect: Boolean): Boolean {
        if (url == "about:blank") return true
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase()

        // intent://, snssdk1233://, market:// и прочие внешние схемы — блокируем
        if (scheme != "http" && scheme != "https") return false
        if (!isTikTokHost(uri.host)) return false

        val path = uri.path ?: ""
        val isFeed = path.isEmpty() || path == "/" ||
            path.startsWith("/foryou") || path.startsWith("/explore") ||
            path.startsWith("/following") || path.startsWith("/discover")
        if (isFeed) return false

        // Переходы на не-видео страницы блокируем, серверные редиректы пропускаем,
        // чтобы не сломать загрузку ролика.
        if (!isRedirect && !isVideoUrl(url)) return false
        return true
    }

    // ───────────────────────── Обработка интентов ─────────────────────────

    private fun handleIntent(intent: Intent?, isNewIntent: Boolean) {
        val raw = when (intent?.action) {
            Intent.ACTION_VIEW -> intent?.dataString
            Intent.ACTION_SEND -> intent?.getStringExtra(Intent.EXTRA_TEXT)
            else -> null
        }
        val url = raw?.let { extractTikTokUrl(it) }
        if (url != null) {
            openedFromOutside = true
            openLink(url)
        } else if (!isNewIntent) {
            if (raw != null) {
                Toast.makeText(this, R.string.not_tiktok_link, Toast.LENGTH_LONG).show()
            }
            showHome()
        }
        // Повторный тап по иконке при открытом ролике ничего не сбрасывает
    }

    private fun openManualLink() {
        val text = linkInput.text.toString().trim()
        hideKeyboard()
        val candidate = if (text.startsWith("http", ignoreCase = true)) text else "https://$text"
        val url = extractTikTokUrl(candidate) ?: extractTikTokUrl(text)
        if (url == null) {
            Toast.makeText(this, R.string.not_tiktok_link, Toast.LENGTH_LONG).show()
            return
        }
        openedFromOutside = false
        openLink(url)
    }

    private fun openLinkSettings() {
        val pkg = Uri.parse("package:$packageName")
        val intents = buildList {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                add(Intent(Settings.ACTION_APP_OPEN_BY_DEFAULT_SETTINGS, pkg))
            }
            add(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg))
        }
        for (i in intents) {
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
                // пробуем следующий вариант
            }
        }
    }

    // ───────────────────────── Ссылки ─────────────────────────

    private fun extractTikTokUrl(text: String): String? =
        URL_REGEX.findAll(text)
            .map { it.value.trimEnd('.', ',', ')', ']', '!', ';') }
            .firstOrNull { isTikTokHost(Uri.parse(it).host) }

    private fun isTikTokHost(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return h == "tiktok.com" || h.endsWith(".tiktok.com")
    }

    private fun isVideoUrl(url: String): Boolean {
        val path = Uri.parse(url).path ?: return false
        return path.contains("/video/") || path.contains("/photo/")
    }

    private fun needsResolve(url: String): Boolean {
        if (isVideoUrl(url)) return false
        val uri = Uri.parse(url)
        val host = uri.host?.lowercase() ?: return false
        val path = uri.path ?: ""
        return host.startsWith("vm.") || host.startsWith("vt.") || path.startsWith("/t/")
    }

    /** Принудительно https и обрезка всех GET-параметров и фрагмента */
    private fun cleanUrl(url: String): String {
        val noHttp = if (url.startsWith("http://", ignoreCase = true)) "https://" + url.substring(7) else url
        return noHttp.substringBefore('#').substringBefore('?')
    }

    private fun openLink(url: String) {
        showViewer()
        progress.visibility = View.VISIBLE
        val id = ++requestId

        if (needsResolve(url)) {
            executor.execute {
                val resolved = resolveRedirects(url)
                runOnUiThread {
                    if (id == requestId && !isDestroyed) load(cleanUrl(resolved))
                }
            }
        } else {
            load(cleanUrl(url))
        }
    }

    /** Проходит по редиректам короткой ссылки до полного URL ролика (/video/ID) */
    private fun resolveRedirects(start: String): String {
        var current = if (start.startsWith("http://", ignoreCase = true)) "https://" + start.substring(7) else start
        repeat(8) {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(current).openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", MOBILE_UA)
                    setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                }
                val code = conn.responseCode
                if (code in 300..399) {
                    val location = conn.getHeaderField("Location") ?: return current
                    current = URL(URL(current), location).toString()
                    if (isVideoUrl(current)) return current
                } else {
                    return current
                }
            } catch (e: Exception) {
                return current
            } finally {
                conn?.disconnect()
            }
        }
        return current
    }

    // ───────────────────────── UI ─────────────────────────

    private fun showHome() {
        home.visibility = View.VISIBLE
        viewer.visibility = View.GONE
    }

    private fun showViewer() {
        home.visibility = View.GONE
        viewer.visibility = View.VISIBLE
    }

    private fun closeViewer() {
        requestId++
        if (openedFromOutside) {
            finish()
        } else {
            session.loadUri("about:blank")
            showHome()
        }
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(linkInput.windowToken, 0)
    }

    private fun setFullscreenMode(enabled: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (enabled) {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    companion object {
        private var runtime: GeckoRuntime? = null

        private const val EXTENSION_LOCATION = "resource://android/assets/cleantok/"
        private const val EXTENSION_ID = "cleantok@cleantok.app"

        private val URL_REGEX = Regex("""https?://[^\s<>"']+""", RegexOption.IGNORE_CASE)

        private const val MOBILE_UA =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/142.0.0.0 Mobile Safari/537.36"
    }
}
